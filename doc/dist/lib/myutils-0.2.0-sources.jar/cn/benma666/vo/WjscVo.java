package cn.benma666.vo;

import cn.benma666.domain.BasicBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import okhttp3.RequestBody;

/**
 * 文件上传虚拟对象
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class WjscVo extends BasicBean {
    /**
     * 文件名
     */
    private String fileName;
    /**
     * 请求体
     */
    private RequestBody requestBody;
}
