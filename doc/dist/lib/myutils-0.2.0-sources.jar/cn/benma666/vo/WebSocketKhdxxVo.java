package cn.benma666.vo;

import cn.benma666.domain.BasicBean;
import cn.benma666.domain.SysPtglXtxx;
import cn.benma666.myutils.StringUtil;
import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;

/**
 * webSocket客户端消息虚拟对象
 */
@Setter
@Getter
public class WebSocketKhdxxVo extends BasicBean {
    /**
     * 消息类别
     */
    private String xxlb;
    /**
     * 目的地大类-对象代码
     */
    private String mdddl;
    /**
     * 目的地小类-记录主键
     */
    private String mddxl;
    /**
     * 数据
     */
    private JSONObject data;
    /**
     * 会话主键
     */
    private String token;

    /**
     * @return 消息目的地代码
     */
    public String getMdd() {
        if(StringUtil.isNotBlank(mdddl)&&StringUtil.isNotBlank(mddxl)){
            return mdddl+"_"+mddxl;
        }else if(StringUtil.isNotBlank(mdddl)){
            return mdddl;
        }
        return SysPtglXtxx.SYS_PTGL_XTXX;
    }
}
