package cn.benma666.vo;

import cn.benma666.iframe.BasicObject;
import lombok.Getter;
import lombok.Setter;

/**
 * 线程池配置
 */
@Setter
@Getter
public class TPConfig extends BasicObject {
    protected Integer corePoolSize;
    protected Integer maxPoolSize;
    protected Integer keepAliveSeconds;
    protected Integer queueCapacity;
}
