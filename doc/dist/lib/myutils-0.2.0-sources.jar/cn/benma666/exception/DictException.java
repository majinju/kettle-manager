/**
* Project Name:myutils
* Date:2018年12月4日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.exception;

/**
 * 字典异常，主要用于预知可控的异常 <br/>
 * date: 2018年12月4日 <br/>
 * @author jingma
 * @version 0.1
 */
public class DictException extends MyException{

    /**
    *
    */
    private static final long serialVersionUID = 1463806345429361813L;
    /**
     * Creates a new instance of ExcelReadException.
     */
    public DictException() {
        this(null,null);
    }

    /**
    * Creates a new instance of ExcelReadException.
    * @param message 消息
    */
    public DictException(String message) {
        this(message,null);
    }
    /**
    * Creates a new instance of ExcelReadException.
    * @param message 消息
    * @param cause 子异常
    */
    public DictException(String message, Throwable cause) {
        super(message, cause);
        setCode(412);
    }
}
