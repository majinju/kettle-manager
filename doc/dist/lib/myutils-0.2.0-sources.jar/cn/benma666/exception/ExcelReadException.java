/**
* Project Name:myutils
* Date:2018年12月4日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.exception;

/**
 * excel读取异常，主要用于预知可控的异常 <br/>
 * date: 2018年12月4日 <br/>
 * @author jingma
 * @version 
 */
public class ExcelReadException extends MyException{

    /**
    * 
    */
    private static final long serialVersionUID = 1463806345429361813L;
    /**
     * Creates a new instance of ExcelReadException.
     */
    public ExcelReadException() {
    }

    /**
    * Creates a new instance of ExcelReadException.
    * @param message
    */
    public ExcelReadException(String message) {
        super(message);
    }
    /**
    * Creates a new instance of ExcelReadException.
    * @param message
    * @param cause
    */
    public ExcelReadException(String message, Throwable cause) {
        super(message, cause);
    }
}
