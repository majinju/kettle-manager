/**
* Project Name:myutils
* Date:2018年12月4日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.exception;

import java.net.HttpURLConnection;

/**
 * 权限异常 <br/>
 * date: 2018年12月4日 <br/>
 * @author jingma
 * @version 0.1
 */
public class QxException extends MyException{

    /**
    *
    */
    private static final long serialVersionUID = 1463806345429361813L;
    /**
     * Creates a new instance of ExcelReadException.
     */
    public QxException() {
    }

    /**
    * Creates a new instance of ExcelReadException.
    * @param message 异常消息
    */
    public QxException(String message) {
        this(message, HttpURLConnection.HTTP_FORBIDDEN);
    }
    /**
    * Creates a new instance of QxException.
    * @param message 异常消息
    * @param code 异常代码
    */
    public QxException(String message, int code) {
        super(message);
        setCode(code);
    }

    /**
    * Creates a new instance of ExcelReadException.
    * @param message 异常消息
    * @param cause 原异常
    */
    public QxException(String message, Throwable cause) {
        super(message, cause);
    }
}
