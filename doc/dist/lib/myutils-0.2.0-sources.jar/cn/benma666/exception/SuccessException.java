package cn.benma666.exception;

import java.net.HttpURLConnection;

public class SuccessException extends MyException{

    /**
     * Creates a new instance of ExcelReadException.
     * @param message 异常消息
     */
    public SuccessException(String message) {
        this(message,null);
    }
    /**
     * Creates a new instance of MyException.
     * @param message 异常消息
     * @param data 数据
     */
    public SuccessException(String message, Object data) {
        super(message, HttpURLConnection.HTTP_OK,data);
    }
}
