/**
* Project Name:myutils
* Date:2018年12月4日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.exception;

/**
 * 字段校验异常，主要用于预知可控的异常 <br/>
 * date: 2018年12月4日 <br/>
 * @author jingma
 * @version 0.1
 */
public class VerifyRuleException extends ExcelReadException{

    /**
    * 
    */
    private static final long serialVersionUID = 1463806345429361813L;
    /**
     * Creates a new instance of ExcelReadException.
     */
    public VerifyRuleException() {
        this(null,null);
    }

    /**
    * Creates a new instance of ExcelReadException.
    * @param message 消息
    */
    public VerifyRuleException(String message) {
        this(message,null);
    }
    /**
    * Creates a new instance of ExcelReadException.
    * @param message 消息
    * @param cause 子异常
    */
    public VerifyRuleException(String message, Throwable cause) {
        super(message, cause);
        setCode(412);
    }
}
