package cn.benma666.config;

import lombok.Getter;
import lombok.Setter;

/**
 * 登录配置
 */
@Setter
@Getter
public class Login {
    /**
     * 是否启用，默认登录
     */
    private Boolean defaultLogin;
    /**
     * 登录失败次数
     */
    private Integer dlsbcs;
    /**
     * 请求并发限制
     */
    private Integer qqbfxz;
    /**
     * 用户同时在线会话数限制
     */
    private Integer tszxhhsxz;
}
