package cn.benma666.config;

import lombok.Getter;
import lombok.Setter;

/**
 * 线程相关配置
 */
@Getter
@Setter
public class ThreadPool {
    /**
     * 核心线程数
     */
    private String corePoolSize;
    /**
     * 最大线程数
     */
    private String maxPoolSize;
    /**
     * 队列大小 缓存多少个任务
     */
    private String queueCapacity;
    /**
     * 线程活跃时间
     */
    private String keepAliveSeconds;
}
