package cn.benma666.config;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * 服务相关配置
 */
@Setter
@Getter
public class Service {
    /**
     * 统一代理地址，应用管理中统一代理的应用都只配置了项目名称，需要读取该配置补充为完整的地址
     */
    private String tydlzd;
    /**
     * 系统接口地址
     */
    private String addr;
    /**
     * 允许上传的文件类型
     */
    private String yxscwjlx;
    /**
     * 权限地址
     */
    private List<String> securityAddr;
    /**
     * 系统根目录
     */
    private String xtgml;
}
