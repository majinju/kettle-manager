package cn.benma666.config;

import lombok.Getter;
import lombok.Setter;

/**
 * 数据相关配置
 */
@Setter
@Getter
public class Data {
    /**
     * 系统主密码
     */
    private String password;
    /**
     * sm2私钥
     */
    private String privateKey;
    /**
     * sm2公钥
     */
    private String publicKey;
}
