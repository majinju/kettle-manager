package cn.benma666.config;

import lombok.Getter;
import lombok.Setter;

/**
 * 智能交换配置
 */
@Getter
@Setter
public class Znjh {
    /**
     * 自动穿透调用，默认1
     */
    private Boolean zdctdy;
    /**
     * 穿透调用等待时长
     */
    private Integer ctdydd;
    /**
     * 默认地址
     */
    private String url;
    /**
     * 默认用户,专用同步账号
     */
    private String user;
    /**
     * 应用初始化启动（非xxl场景支持），目前建议优先采用xxl调度，方便管理。
     */
    private String appInitStart;
    /**
     * 分页大小
     */
    private Integer pageSize;
    /**
     * 线程池配置
     */
    private ThreadPool threadPool;
}
