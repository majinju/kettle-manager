package cn.benma666.dict;

import lombok.Getter;

/**
 * 运行状态
 */
@Getter
public enum Yxzt {
    /**
     * 状态-未知
     */
    UNKNOW(1),
    /**
     * 状态-成功
     */
    SUCCESS(1),
    /**
     * 状态-失败
     */
    FAILED(2);
    private final int code;
    Yxzt(int code){
        this.code = code;
    }
}
