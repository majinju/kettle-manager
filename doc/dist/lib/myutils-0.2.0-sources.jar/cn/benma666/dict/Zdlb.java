package cn.benma666.dict;

/**
 * 字典类别
 */
public enum Zdlb {
    /**
     * 字典类别-系统-公用-字典类别
     */
    SYS_COMMON_ZDLB,
    /**
     * 字典类别-系统-公用-逻辑判断
     */
    SYS_COMMON_LJPD,
    /**
     * 字典类别-系统-公用-星期
     */
    SYS_COMMON_XQ,
    /**
     * 字典-系统-通用-数据载体
     */
    SYS_COMMON_SJZT,
    /**
     * 字典-系统-权限-应用
     */
    SYS_QX_APP
}
