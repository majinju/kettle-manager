package cn.benma666.dict;

import lombok.Getter;

/**
 * 处理类型
 */
@Getter
public enum Cllx {
    /**
     * 处理类型-系统基础信息
     */
    xtjcxx,
    /**
     * 处理类型-对象基础信息
     */
    dxjcxx,
    /**
     * 处理类型-统一回调方法，针对异步回调方法场景
     */
    tyhd,
    /**
     * 处理类型-新增
     */
    insert,
    /**
     * 处理类型-更新
     */
    update,
    /**
     * 处理类型-保存：含插入和更新，底层会自动判断
     */
    save,
    /**
     * 处理类型-分页查询
     */
    select,
    /**
     * 处理类型-删除
     */
    delete,
    /**
     * 处理类型-批量删除
     */
    plsc,
    /**
     * 处理类型-物理批量删除
     */
    wlplsc,
    /**
     * 处理类型-批量保存
     */
    plbc,
    /**
     * 处理类型-数据批量上传
     */
    sjplsc,
    /**
     * 处理类型-获取文件
     */
    getfile,
    /**
     * 处理类型-批量处理
     */
    plcl,
    /**
     * 处理类型-获取数据
     */
    getdata,
    /**
     * 处理类型-导出当前页数据
     */
    dcdqysj,
    /**
     * 处理类型-导出数据
     */
    dcsj,
    /**
     * 处理类型-导出模板
     */
    dcmb,
    /**
     * 处理类型-websocket目的地注册
     */
    wsmddzc,
    /**
     * 处理类型-websocket目的地取消
     */
    wsmddqx,
    /**
     * 批量数据转换验证
     */
    plsjzhyz,
    /**
     * 上传
     */
    upload
}
