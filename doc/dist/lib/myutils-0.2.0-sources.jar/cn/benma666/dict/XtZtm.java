package cn.benma666.dict;

import lombok.Getter;

/**
 * 系统-状态码
 */
@Getter
public enum XtZtm {
    /**
     * 穿透调用超时
     */
    CTDYCS(1000),
    /**
     * 数据批量上传校验不通过
     */
    SJPLSCJYBTG(1001),
    /**
     * 等待回调超时
     */
    DDHDCS(1002),
    /**
     * 定制处理结果，不进行统一处理
     */
    DZCLJG(9999);
    private final int code;
    XtZtm(int code){
        this.code = code;
    }
}
