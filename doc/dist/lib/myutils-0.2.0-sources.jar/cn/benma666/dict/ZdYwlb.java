package cn.benma666.dict;

import lombok.Getter;

/**
 * 字段业务类别
 */
@Getter
public enum ZdYwlb {
    XNZD("99"),
    ;
    private final String code;
    ZdYwlb(String code){
        this.code = code;
    }
}
