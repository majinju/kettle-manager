package cn.benma666.dict;

import lombok.Getter;

/**
 * 字段-控件类型
 */
@Getter
public enum ZdKjlx {
    /**
     * 下拉选择框
     */
    Select("$select"),
    /**
     * 开关
     */
    Switch("$switch"),
    /**
     * 复选框
     */
    Checkbox("$checkbox"),
    /**
     * 级联选择框
     */
    ElCascader("ElCascader"),
    /**
     * 单选
     */
    Radio("$radio"),
    /**
     * 字典-数据对象-控件类型-输入框
     */
    Input("$input"),
    /**
     * 字典-数据对象-控件类型-时间框
     */
    ElDatePicker("ElDatePicker"),
    /**
     * 字典-数据对象-控件类型-密码
     */
    Password("password"),
    /**
     * 字典-数据对象-控件类型-数字
     */
    Number("number"),
    /**
     * 图片
     */
    MyImage("MyImage"),
    /**
     * 按钮组
     */
    Buttons("$buttons"),
    /**
     * 查询表格
     */
    MySelectGrid("MySelectGrid"),
    /**
     * 页面字段分组
     */
    MyGroup("MyGroup")
    ;
    private final String code;
    ZdKjlx(String code){
        this.code = code;
    }
    public static ZdKjlx getByCode(String code) {
        for (ZdKjlx zdKjlx : values()) {
            if (zdKjlx.getCode().equals(code)) {
                return zdKjlx;
            }
        }
        return null;
    }
}
