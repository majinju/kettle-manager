package cn.benma666.dict;

import lombok.Getter;

/**
 * 逻辑判断
 */
@Getter
public enum Ljpd {
    TURE(1),
    FALSE(0);
    private final int code;
    Ljpd(int code){
        this.code = code;
    }
}
