/**
 * Project Name:myutils
 * Date:2018年12月29日
 * Copyright (c) 2018, jingma All Rights Reserved.
 */

package cn.benma666.main;

import org.h2.tools.Server;

import java.sql.SQLException;
/**
 * 调用h2服务<br/>
 * date: 2018年12月29日 <br/>
 * @author jingma
 * @version
 */
public class H2Server {
    public static void main(String[] args) throws SQLException {
        Server.main(new String[] { "-tcpAllowOthers", "-webAllowOthers", "-webPort", "8182" });
    }
}
