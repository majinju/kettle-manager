package cn.benma666.myutils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Description: 日志辅助类
 *
 */
public class Log {
    /**
    * 日志
    */
    public static Logger log = LoggerFactory.getLogger(Log.class);
	
	public static Logger getLogger(){
		return log;
	}
}
