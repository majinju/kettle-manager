/**
* by jingma 2022-04-02
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-服务器
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "sys_qx_fwq")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysQxFwq extends BasicBean{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private BigDecimal px;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * IP
	 */
	@Column(name = "IP")
	private String ip;
	/**
	 * 描述
	 */
	@Column(name = "MS")
	private String ms;
	/**
	 * 类别@SYS_QX_FWQLB
	 */
	@Column(name = "LB")
	private String lb;
	/**
	 * 名称
	 */
	@Column(name = "MC")
	private String mc;
	/**
	 * 类型@SYS_QX_FWQLX;win、 linux
	 */
	@Column(name = "LX")
	private String lx;
	/**
	 * 密码
	 */
	@Column(name = "MM")
	private String mm;
	/**
	 * 负责人
	 */
	@Column(name = "FZR")
	private String fzr;
	/**
	 * 状态@SYS_COMMON_ZT
	 */
	@Column(name = "ZT")
	private String zt;
	/**
	 * 远程端口
	 */
	@Column(name = "YCDK")
	private String ycdk;
	/**
	 * 用户名
	 */
	@Column(name = "YHM")
	private String yhm;
}
