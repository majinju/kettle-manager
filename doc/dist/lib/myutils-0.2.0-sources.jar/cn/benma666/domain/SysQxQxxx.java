/**
* by jingma 2023-10-23
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;

/**
 * 系统-权限-权限信息
 */
@Entity
@Table(name = "sys_qx_qxxx")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysQxQxxx extends BasicBean{

	/**
	 * 父权限@SYS_QX_QXXX;父权限
	 */
	@Column(name = "fqx")
	private String fqx;
	/**
	 * 代码;代码
	 */
	@Column(name = "dm")
	private String dm;
	/**
	 * 名称;名称
	 */
	@Column(name = "mc")
	private String mc;
	/**
	 * 描述;描述
	 */
	@Column(name = "ms")
	private String ms;
	/**
	 * 类型@SYS_QX_QXLX;类型@SYS_QX_QXLX
	 */
	@Column(name = "lx")
	private String lx;
	/**
	 * 所属应用@SYS_QX_APP;所属应用@SYS_QX_APP
	 */
	@Column(name = "ssyy")
	private String ssyy;
	/**
	 * 支持手机端@SYS_COMMON_LJPD;支持手机端
	 */
	@Column(name = "zcsjd")
	private String zcsjd;
	/**
	 * 备注;备注
	 */
	@Column(name = "bz")
	private String bz;
	/**
	 * 地址类型@SYS_QX_QXDZLX;地址类型，当为数据对象时会自动生成自带子权限
	 */
	@Column(name = "dzlx")
	private String dzlx;
	/**
	 * 打开方式@SYS_QX_QXDKFS;打开方式@SYS_QX_QXDKFS
	 */
	@Column(name = "dkfs")
	private String dkfs;
	/**
	 * 数据对象@SYS_SJGL_SJDX;SYS_SJGL_SJDX
	 */
	@Column(name = "sjdx")
	private String sjdx;
	/**
	 * 权限地址;权限地址
	 */
	@Column(name = "dz")
	private String dz;
	/**
	 * 图标@SYS_SJGL_ICON;对应文件管理的主键
	 */
	@Column(name = "tb")
	private String tb;
	/**
	 * 排序;排序
	 */
	@Column(name = "px")
	private BigDecimal px;
	/**
	 * 有效性@SYS_COMMON_LJPD;有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "yxx")
	private String yxx;
	/**
	 * 更新时间;更新时间
	 */
	@Column(name = "gxsj")
	private String gxsj;
	/**
	 * 主键;主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "id")
	private String id;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "kzxx")
	private String kzxx;
	/**
	 * 创建时间;创建时间
	 */
	@Column(name = "cjsj")
	private String cjsj;
	/**
	 * 创建人姓名;创建人姓名
	 */
	@Column(name = "cjrxm")
	private String cjrxm;
	/**
	 * 创建人代码@SYS_COMMON_USER;创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "cjrdm")
	private String cjrdm;
	/**
	 * 创建人单位名称;创建人单位名称
	 */
	@Column(name = "cjrdwmc")
	private String cjrdwmc;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG;创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "cjrdwdm")
	private String cjrdwdm;
	/**
	 * 名称简拼;名称简拼
	 */
	@Column(name = "mcjp")
	private String mcjp;
	/**
	 * 名称全拼;名称全拼
	 */
	@Column(name = "mcqp")
	private String mcqp;
	/**
	 * 图片图标;主要是移动端使用
	 */
	@Column(name = "tptb")
	private String tptb;
	/**
	 * 是否有子权限
	 */
	@Transient
	private String myhaschild;
}
