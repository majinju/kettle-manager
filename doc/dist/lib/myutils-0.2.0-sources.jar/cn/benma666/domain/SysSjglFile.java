/**
* by jingma 2019-04-18
*/
package cn.benma666.domain;

import cn.benma666.constants.UtilConst;
import cn.benma666.dict.Xzms;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.myutils.DateUtil;
import cn.benma666.myutils.FileUtil;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjzt.DbFile;
import cn.benma666.sjzt.IFile;
import cn.benma666.sjzt.SjsjEntity;
import com.alibaba.druid.util.Utils;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;

/**
 * 系统-数据管理-文件
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_SJGL_FILE")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
@Slf4j
public class SysSjglFile extends BasicBean{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	public SysSjglFile(String sclj, String sjzt) {
		setSclj(sclj);
		this.sjzt = sjzt;
	}

    /**
     * 主键
     */
    @Id
    @GeneratedValue(generator="idGenerator")
    @Column(name = "ID")
    private String id;

    /**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 文件类型
	 */
	@Column(name = "WJLX")
	private String wjlx;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 业务代码;ZDRY_RYGL
	 */
	@Column(name = "YWDM")
	private String ywdm;
	/**
	 * 关联id;前端传
	 */
	@Column(name = "GLID")
	private String glid;
	/**
	 * 上传路径;ZDRY_RYGL/去重码.wjlx
	 */
	@Column(name = "SCLJ")
	private String sclj;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 文件名
	 */
	@Column(name = "WJM")
	private String wjm;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private BigDecimal px;
    /**
     * 文件大小
     */
    @Column(name = "WJDX")
    private long wjdx;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 文件类别
	 */
	@Column(name = "WJLB")
	private String wjlb;
	/**
	 * 数据载体
	 */
	@Column(name = "SJZT")
	private String sjzt;
	/**
	 * 去重码
	 */
	@Column(name = "QCM")
	private String qcm;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	* 下载模式，1：按文件类型下载、2：二进制文件下载、3：base64、4：转为base64后作为data以json对象返回
	*/
	@Transient
	private int xzms = Xzms.AWJLXXZ.getCode();
	/**
	 * 文件内容
	 */
	@Transient
	private String wjnr;
	/**
	 * 父路径
	 */
	private String parent;
	/**
	 * 按日期分文件夹
	 */
	@Transient
	private boolean arqfwjj = true;
	/**
	 * 文件名加后缀
	 */
	@Transient
	private boolean wjmjhz = true;
	/**
	 * 数据数组
	 */
	@Transient
	private byte[] bytes;

	/**
	 * 获取该文件的二进制数据
	 */
	@JSONField(serialize = false)
	public byte[] getFileBytes() {
		InputStream in = null;
		try {
			in = getInputStream();
			return Utils.readByteArray(in);
		} catch (IOException e) {
			log.error("文件读取异常："+this,e);
			throw new MyException("文件读取异常："+e.getMessage(),e);
		}finally {
			FileUtil.closeStream(in);
		}
	}

	/**
	 * 获取文件输入流
	 */
	@JSONField(serialize = false)
	public InputStream getInputStream(){
		try {
			return toIFile().getInputStream();
		} catch (Exception e) {
			throw new MyException("文件读取异常："+ this.getSclj(),e);
		}
	}

	/**
	 * 删除文件
	 */
	public boolean delete(){
		//数据载体为本地文件时
		try {
			return toIFile().delete();
		} catch (Exception e) {
			throw new MyException("文件没有找到："+ this.getSclj());
		}
	}
	public IFile toIFile(){
		DbFile ifile = new DbFile(this);
		if(StringUtil.isBlank(getId())){
			//id为空表示新增场景
			setId(StringUtil.getUUIDUpperStr());
			if(isWjmjhz()){
				ifile.setName(getWjm().substring(0, getWjm().lastIndexOf('.'))+"_"
						+ System.currentTimeMillis() + "." + getWjlx());
			}
		}
		return ifile;
	}

	public void setSclj(String sclj) {
		this.sclj = sclj;
		if(StringUtil.isBlank(sclj)){
			return;
		}
		File f = new File(sclj);
		if(StringUtil.isBlank(getWjm())){
			setWjm(f.getName());
		}
	}

	public void setWjm(String wjm) {
		this.wjm = wjm;
		if(StringUtil.isBlank(getWjlx())&&wjm.contains(".")){
			setWjlx(wjm.substring(wjm.lastIndexOf(".")+1).toLowerCase());
		}
	}

	public String getParent() {
		if(StringUtil.isBlank(parent)){
			parent = "";
			if (isArqfwjj()) {
				//指定设置要求不按日期分文件夹
				parent += DateUtil.getDateTimeStr(DateUtil.DATE_FORMATTER8) + UtilConst.FXG;
			}
			if(StringUtil.isNotBlank(getYwdm())){
				parent += getYwdm() + UtilConst.FXG;
			}
			if(StringUtil.isNotBlank(getWjlb())){
				parent += getWjlb() + UtilConst.FXG;
			}
		}
		return parent;
	}

	public String getSjzt() {
		if (StringUtil.isBlank(sjzt)) {
			//设置默认数据载体
			sjzt = Conf.getVal("wjsc.mrsjzt");
		}
		return sjzt;
	}
}
