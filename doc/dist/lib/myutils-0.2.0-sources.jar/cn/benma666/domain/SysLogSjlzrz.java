/**
* by jingma 2022-08-22
*/
package cn.benma666.domain;

import cn.benma666.dict.Yxzt;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-日志-数据流转日志
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_LOG_SJLZRZ")
@Getter
@Setter
public class SysLogSjlzrz extends BasicBean{

	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 数据对象
	 */
	@Column(name = "SJDX")
	private String sjdx;
	/**
	 * 数据账单
	 */
	@Column(name = "SJZD")
	private String sjzd;
	/**
	 * 作业
	 */
	@Column(name = "ZY")
	private String zy;
	/**
	 * 作业名称
	 */
	@Column(name = "ZYMC")
	private String zymc;
	/**
	 * 开始时间
	 */
	@Column(name = "KSSJ")
	private String kssj;
	/**
	 * 结束时间
	 */
	@Column(name = "JSSJ")
	private String jssj;
	/**
	 * 抽取标志
	 */
	@Column(name = "ZLSJC")
	private String zlsjc;
	/**
	 * 结果
	 */
	@Column(name = "JG")
	private Integer jg = Yxzt.UNKNOW.getCode();
	/**
	 * 读取量
	 */
	@Column(name = "DQL")
	private BigDecimal dql = BigDecimal.ZERO;
	/**
	 * 新增量
	 */
	@Column(name = "XZL")
	private BigDecimal xzl;
	/**
	 * 重复量
	 */
	@Column(name = "CFL")
	private BigDecimal cfl;
	/**
	 * 无效量
	 */
	@Column(name = "WXL")
	private BigDecimal wxl;
	/**
	 * 备注
	 */
	@Column(name = "bz")
	private String bz;
}
