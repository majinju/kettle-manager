/**
* by jingma 2019-04-18
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-数据管理-统一字典
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_SJGL_TYZD")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysSjglTyzd extends BasicBean{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 字典类别
	 */
	@Column(name = "ZDLB")
	private String zdlb;
	/**
	 * 主键
	 */
	@Id
    @GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 描述
	 */
	@Column(name = "MS")
	private String ms;
	/**
	 * 简拼
	 */
	@Column(name = "JP")
	private String jp;
	/**
	 * 父节点
	 */
	@Column(name = "UPNODE")
	private String upnode;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 名称
	 */
	@Column(name = "MC")
	private String mc;
	/**
	 * 是否缓存
	 */
	@Column(name = "CACHE")
	private String cache;
	/**
	 * 类别SQL;当次SQL为空时，字典默认在此统一字典表中，有SQL则通过SQL获取字典
	 */
	@Column(name = "LBSQL")
	private String lbsql;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 代码
	 */
	@Column(name = "DM")
	private String dm;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 标准字典;用于数据标准化等场景，如性别可以有几套字典，然后关联一个标准字典,进一步通过mc关联
	 */
	@Column(name = "BZZD")
	private String bzzd;
	/**
	 * 排序;建议排序都按10、20、30的方式排序，方便修改穿插
	 */
	@Column(name = "PX")
	private BigDecimal px;
	/**
	 * 数据来源
	 */
	@Column(name = "SJLY")
	private String sjly;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 全拼
	 */
	@Column(name = "QP")
	private String qp;

    /**
    * 其他参数
    */
    private String otherParam;

    /**
    * 搜索框需要翻译的值
    */
    private String searchValue;
    /**
    * 搜索关键字
    */
    private String searchKey;

    /**
    * 返回结果是否进行JSON格式化
    */
    private boolean jsongsh;

	/**
	 * @return 字典类别
	 */
	public String getZdlb() {
		return zdlb;
	}
	/**
	 * @param zdlb 字典类别
	 */
	public void setZdlb(String zdlb) {
		this.zdlb = zdlb;
	}

	/**
	 * @return 主键
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id 主键
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return 描述
	 */
	public String getMs() {
		return ms;
	}
	/**
	 * @param ms 描述
	 */
	public void setMs(String ms) {
		this.ms = ms;
	}

	/**
	 * @return 简拼
	 */
	public String getJp() {
		return jp;
	}
	/**
	 * @param jp 简拼
	 */
	public void setJp(String jp) {
		this.jp = jp;
	}

	/**
	 * @return 父节点
	 */
	public String getUpnode() {
		return upnode;
	}
	/**
	 * @param upnode 父节点
	 */
	public void setUpnode(String upnode) {
		this.upnode = upnode;
	}

	/**
	 * @return 更新时间
	 */
	public String getGxsj() {
		return gxsj;
	}
	/**
	 * @param gxsj 更新时间
	 */
	public void setGxsj(String gxsj) {
		this.gxsj = gxsj;
	}

	/**
	 * @return 名称
	 */
	public String getMc() {
		return mc;
	}
	/**
	 * @param mc 名称
	 */
	public void setMc(String mc) {
		this.mc = mc;
	}

	/**
	 * @return 是否缓存
	 */
	public String getCache() {
		return cache;
	}
	/**
	 * @param cache 是否缓存
	 */
	public void setCache(String cache) {
		this.cache = cache;
	}

	/**
	 * @return 类别SQL;当次SQL为空时，字典默认在此统一字典表中，有SQL则通过SQL获取字典
	 */
	public String getLbsql() {
		return lbsql;
	}
	/**
	 * @param lbsql 类别SQL;当次SQL为空时，字典默认在此统一字典表中，有SQL则通过SQL获取字典
	 */
	public void setLbsql(String lbsql) {
		this.lbsql = lbsql;
	}

	/**
	 * @return 创建人姓名
	 */
	public String getCjrxm() {
		return cjrxm;
	}
	/**
	 * @param cjrxm 创建人姓名
	 */
	public void setCjrxm(String cjrxm) {
		this.cjrxm = cjrxm;
	}

	/**
	 * @return 创建人代码@SYS_COMMON_USER
	 */
	public String getCjrdm() {
		return cjrdm;
	}
	/**
	 * @param cjrdm 创建人代码@SYS_COMMON_USER
	 */
	public void setCjrdm(String cjrdm) {
		this.cjrdm = cjrdm;
	}

	/**
	 * @return 代码
	 */
	public String getDm() {
		return dm;
	}
	/**
	 * @param dm 代码
	 */
	public void setDm(String dm) {
		this.dm = dm;
	}

	/**
	 * @return 创建人单位代码@SYS_COMMON_ORG
	 */
	public String getCjrdwdm() {
		return cjrdwdm;
	}
	/**
	 * @param cjrdwdm 创建人单位代码@SYS_COMMON_ORG
	 */
	public void setCjrdwdm(String cjrdwdm) {
		this.cjrdwdm = cjrdwdm;
	}

	/**
	 * @return 创建人单位名称
	 */
	public String getCjrdwmc() {
		return cjrdwmc;
	}
	/**
	 * @param cjrdwmc 创建人单位名称
	 */
	public void setCjrdwmc(String cjrdwmc) {
		this.cjrdwmc = cjrdwmc;
	}

	/**
	 * @return 有效性@SYS_COMMON_LJPD
	 */
	public String getYxx() {
		return yxx;
	}
	/**
	 * @param yxx 有效性@SYS_COMMON_LJPD
	 */
	public void setYxx(String yxx) {
		this.yxx = yxx;
	}

	/**
	 * @return 创建时间
	 */
	public String getCjsj() {
		return cjsj;
	}
	/**
	 * @param cjsj 创建时间
	 */
	public void setCjsj(String cjsj) {
		this.cjsj = cjsj;
	}

	/**
	 * @return 标准字典;用于数据标准化等场景，如性别可以有几套字典，然后关联一个标准字典,进一步通过mc关联
	 */
	public String getBzzd() {
		return bzzd;
	}
	/**
	 * @param bzzd 标准字典;用于数据标准化等场景，如性别可以有几套字典，然后关联一个标准字典,进一步通过mc关联
	 */
	public void setBzzd(String bzzd) {
		this.bzzd = bzzd;
	}

	/**
	 * @return 排序;建议排序都按10、20、30的方式排序，方便修改穿插
	 */
	public BigDecimal getPx() {
		return px;
	}
	/**
	 * @param px 排序;建议排序都按10、20、30的方式排序，方便修改穿插
	 */
	public void setPx(BigDecimal px) {
		this.px = px;
	}

	/**
	 * @return 数据来源
	 */
	public String getSjly() {
		return sjly;
	}
	/**
	 * @param sjly 数据来源
	 */
	public void setSjly(String sjly) {
		this.sjly = sjly;
	}

	/**
	 * @return 扩展信息;JSON格式
	 */
	public String getKzxx() {
		return kzxx;
	}
	/**
	 * @param kzxx 扩展信息;JSON格式
	 */
	public void setKzxx(String kzxx) {
		this.kzxx = kzxx;
	}

	/**
	 * @return 全拼
	 */
	public String getQp() {
		return qp;
	}
	/**
	 * @param qp 全拼
	 */
	public void setQp(String qp) {
		this.qp = qp;
	}
    /**
     * @return otherParam
     */
    public String getOtherParam() {
        return otherParam;
    }
    /**
     * @param otherParam the otherParam to set
     */
    public void setOtherParam(String otherParam) {
        this.otherParam = otherParam;
    }
    /**
     * @return searchValue
     */
    public String getSearchValue() {
        return searchValue;
    }
    /**
     * @param searchValue the searchValue to set
     */
    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue;
    }
    /**
     * @return searchKey
     */
    public String getSearchKey() {
        return searchKey;
    }
    /**
     * @param searchKey the searchKey to set
     */
    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }
    /**
     * @return jsongsh
     */
    public boolean isJsongsh() {
        return jsongsh;
    }
    /**
     * @param jsongsh the jsongsh to set
     */
    public void setJsongsh(boolean jsongsh) {
        this.jsongsh = jsongsh;
    }

}
