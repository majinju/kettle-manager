/**
* by jingma 2018-12-12
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-数据管理-用户自定义
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_SJGL_YHZDY")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysSjglYhzdy extends BasicBean{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 查询展示@SYS_COMMON_LJPD
	 */
	@Column(name = "CXZS")
	private String cxzs;
	/**
	 * 列表展示@SYS_COMMON_LJPD
	 */
	@Column(name = "LBZS")
	private String lbzs;
	/**
	 * 数据对象
	 */
	@Column(name = "SJDX")
	private String sjdx;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 数据字段
	 */
	@Column(name = "SJZD")
	private String sjzd;
	/**
	 * 默认值
	 */
	@Column(name = "MRZ")
	private String mrz;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWBM")
	private String cjrdwbm;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private BigDecimal px;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;

	/**
	 * @return 主键
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id 主键
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return 查询展示@SYS_COMMON_LJPD
	 */
	public String getCxzs() {
		return cxzs;
	}
	/**
	 * @param cxzs 查询展示@SYS_COMMON_LJPD
	 */
	public void setCxzs(String cxzs) {
		this.cxzs = cxzs;
	}

	/**
	 * @return 列表展示@SYS_COMMON_LJPD
	 */
	public String getLbzs() {
		return lbzs;
	}
	/**
	 * @param lbzs 列表展示@SYS_COMMON_LJPD
	 */
	public void setLbzs(String lbzs) {
		this.lbzs = lbzs;
	}

	/**
	 * @return 数据对象
	 */
	public String getSjdx() {
		return sjdx;
	}
	/**
	 * @param sjdx 数据对象
	 */
	public void setSjdx(String sjdx) {
		this.sjdx = sjdx;
	}

	/**
	 * @return 创建人单位名称
	 */
	public String getCjrdwmc() {
		return cjrdwmc;
	}
	/**
	 * @param cjrdwmc 创建人单位名称
	 */
	public void setCjrdwmc(String cjrdwmc) {
		this.cjrdwmc = cjrdwmc;
	}

	/**
	 * @return 有效性@SYS_COMMON_LJPD
	 */
	public String getYxx() {
		return yxx;
	}
	/**
	 * @param yxx 有效性@SYS_COMMON_LJPD
	 */
	public void setYxx(String yxx) {
		this.yxx = yxx;
	}

	/**
	 * @return 数据字段
	 */
	public String getSjzd() {
		return sjzd;
	}
	/**
	 * @param sjzd 数据字段
	 */
	public void setSjzd(String sjzd) {
		this.sjzd = sjzd;
	}

	/**
	 * @return 默认值
	 */
	public String getMrz() {
		return mrz;
	}
	/**
	 * @param mrz 默认值
	 */
	public void setMrz(String mrz) {
		this.mrz = mrz;
	}

	/**
	 * @return 更新时间
	 */
	public String getGxsj() {
		return gxsj;
	}
	/**
	 * @param gxsj 更新时间
	 */
	public void setGxsj(String gxsj) {
		this.gxsj = gxsj;
	}

	/**
	 * @return 创建人单位代码@SYS_COMMON_ORG
	 */
	public String getCjrdwbm() {
		return cjrdwbm;
	}
	/**
	 * @param cjrdwbm 创建人单位代码@SYS_COMMON_ORG
	 */
	public void setCjrdwbm(String cjrdwbm) {
		this.cjrdwbm = cjrdwbm;
	}

	/**
	 * @return 扩展信息;JSON格式
	 */
	public String getKzxx() {
		return kzxx;
	}
	/**
	 * @param kzxx 扩展信息;JSON格式
	 */
	public void setKzxx(String kzxx) {
		this.kzxx = kzxx;
	}

	/**
	 * @return 创建人代码@SYS_COMMON_USER
	 */
	public String getCjrdm() {
		return cjrdm;
	}
	/**
	 * @param cjrdm 创建人代码@SYS_COMMON_USER
	 */
	public void setCjrdm(String cjrdm) {
		this.cjrdm = cjrdm;
	}

	/**
	 * @return 排序
	 */
	public BigDecimal getPx() {
		return px;
	}
	/**
	 * @param px 排序
	 */
	public void setPx(BigDecimal px) {
		this.px = px;
	}

	/**
	 * @return 创建人姓名
	 */
	public String getCjrxm() {
		return cjrxm;
	}
	/**
	 * @param cjrxm 创建人姓名
	 */
	public void setCjrxm(String cjrxm) {
		this.cjrxm = cjrxm;
	}

	/**
	 * @return 创建时间
	 */
	public String getCjsj() {
		return cjsj;
	}
	/**
	 * @param cjsj 创建时间
	 */
	public void setCjsj(String cjsj) {
		this.cjsj = cjsj;
	}

}
