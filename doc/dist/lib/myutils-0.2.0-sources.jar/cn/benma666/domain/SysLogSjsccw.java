/**
* by jingma 2021-10-02
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-日志-数据上传错误
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_LOG_SJSCCW")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysLogSjsccw extends BasicBean{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	public SysLogSjsccw(String sjwj, String sjz, String sjlm, String sjh, String sjdx, String sjl,String cwxx,String qqid) {
		this.sjwj = sjwj;
		this.sjz = sjz;
		this.sjlm = sjlm;
		this.sjh = sjh;
		this.sjdx = sjdx;
		this.sjl = sjl;
		this.cwxx = cwxx;
		this.qqid = qqid;
	}

	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 数据文件
	 */
	@Column(name = "SJWJ")
	private String sjwj;
	/**
	 * 数据值
	 */
	@Column(name = "SJZ")
	private String sjz;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 错误信息
	 */
	@Column(name = "CWXX")
	private String cwxx;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * 数据列名
	 */
	@Column(name = "SJLM")
	private String sjlm;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private BigDecimal px;
	/**
	 * 数据行
	 */
	@Column(name = "SJH")
	private String sjh;
	/**
	 * 数据对象
	 */
	@Column(name = "SJDX")
	private String sjdx;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 数据列
	 */
	@Column(name = "SJL")
	private String sjl;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 请求ID
	 */
	@Column(name = "QQID")
	private String qqid;
}
