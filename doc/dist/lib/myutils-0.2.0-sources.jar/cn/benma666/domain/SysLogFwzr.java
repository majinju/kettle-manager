/**
* by jingma 2018-12-20
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * 系统-日志-访问日志
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_LOG_FWZR")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysLogFwzr extends BasicBean{

	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 操作ip
	 */
	@Column(name = "CZIP")
	private String czip;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 权限id
	 */
	@Column(name = "TOKEN")
	private String token;
	/**
	 * URL
	 */
	@Column(name = "URL")
	private String url;
	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 操作类型
	 */
	@Column(name = "CZLX")
	private String czlx;
	/**
	 * 相关参数
	 */
	@Column(name = "XGCS")
	private String xgcs;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 数据对象
	 */
	@Column(name = "SJDX")
	private String sjdx;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private int px;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
    /**
     * 数据记录;对应操作记录的主键
     */
    @Column(name = "SJJL")
    private String sjjl;
	/**
	 * 返回内容;不保存data
	 */
	@Column(name = "FHNR")
	private String fhnr;
	/**
	 * 请求耗时
	 */
	@Column(name = "QQHS")
	private long qqhs;
	/**
	 * 返回结果
	 */
	@Column(name = "FHJG")
	private int fhjg;
	/**
	 * 返回代码
	 */
	@Column(name = "FHDM")
	private String fhdm;
	/**
	 * 返回消息
	 */
	@Column(name = "FHXX")
	private String fhxx;
	/**
	 * 菜单路径
	 */
	@Column(name = "CDLJ")
	private String cdlj;
	/**
	 * 操作类型名称
	 */
	@Column(name = "CZLXMC")
	private String czlxmc;
	/**
	 * 调度节点
	 */
	@Column(name = "DDJD")
	private String ddjd;
}
