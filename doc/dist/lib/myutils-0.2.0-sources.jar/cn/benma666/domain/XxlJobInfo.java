/**
* by jingma 2022-09-15
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 *
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "xxl_job_info")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class XxlJobInfo extends BasicBean{

	/**
	 *
	 */
	@Column(name = "add_time")
	private String add_time;
	/**
	 * 报警邮件
	 */
	@Column(name = "alarm_email")
	private String alarm_email;
	/**
	 * 作者
	 */
	@Column(name = "author")
	private String author;
	/**
	 * 子任务ID，多个逗号分隔
	 */
	@Column(name = "child_jobid")
	private String child_jobid;
	/**
	 * 阻塞处理策略
	 */
	@Column(name = "executor_block_strategy")
	private String executor_block_strategy;
	/**
	 * 失败重试次数
	 */
	@Column(name = "executor_fail_retry_count")
	private BigDecimal executor_fail_retry_count;
	/**
	 * 执行器任务handler
	 */
	@Column(name = "executor_handler")
	private String executor_handler;
	/**
	 * 执行器任务参数
	 */
	@Column(name = "executor_param")
	private String executor_param;
	/**
	 * 执行器路由策略
	 */
	@Column(name = "executor_route_strategy")
	private String executor_route_strategy;
	/**
	 * 任务执行超时时间，单位秒
	 */
	@Column(name = "executor_timeout")
	private BigDecimal executor_timeout;
	/**
	 * GLUE备注
	 */
	@Column(name = "glue_remark")
	private String glue_remark;
	/**
	 * GLUE源代码
	 */
	@Column(name = "glue_source")
	private String glue_source;
	/**
	 * GLUE类型
	 */
	@Column(name = "glue_type")
	private String glue_type;
	/**
	 * GLUE更新时间
	 */
	@Column(name = "glue_updatetime")
	private String glue_updatetime;
	/**
	 *
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "id")
	private BigDecimal id;
	/**
	 *
	 */
	@Column(name = "job_desc")
	private String job_desc;
	/**
	 * 执行器主键ID
	 */
	@Column(name = "job_group")
	private BigDecimal job_group;
	/**
	 * 调度过期策略
	 */
	@Column(name = "misfire_strategy")
	private String misfire_strategy;
	/**
	 * 调度配置，值含义取决于调度类型
	 */
	@Column(name = "schedule_conf")
	private String schedule_conf;
	/**
	 * 调度类型
	 */
	@Column(name = "schedule_type")
	private String schedule_type;
	/**
	 * 上次调度时间
	 */
	@Column(name = "trigger_last_time")
	private BigDecimal trigger_last_time;
	/**
	 * 下次调度时间
	 */
	@Column(name = "trigger_next_time")
	private BigDecimal trigger_next_time;
	/**
	 * 调度状态：0-停止，1-运行
	 */
	@Column(name = "trigger_status")
	private String trigger_status;
	/**
	 *
	 */
	@Column(name = "update_time")
	private String update_time;
}
