/**
* by jingma 2022-11-29
*/
package cn.benma666.domain;

import cn.benma666.sjzt.SjsjEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * 系统-数据管理-数据库文件
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "sys_sjgl_blob")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SjsjEntity
public class SysSjglBlob extends BasicBean{

	/**
	 * 内容;内容
	 */
	@Column(name = "nr")
	private byte[] nr;
	/**
	 * 创建时间;
	 */
	@Column(name = "cjsj")
	private String cjsj;
	/**
	 * 更新时间;
	 */
	@Column(name = "gxsj")
	private String gxsj;
	/**
	 * 有效性@SYS_COMMON_LJPD;
	 */
	@Column(name = "yxx")
	private String yxx;
	/**
	 * 主键;
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "id")
	private String id;
}
