/**
* by jingma 2022-07-26
*/
package cn.benma666.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * 系统-数据管理-后台任务
 */
@javax.persistence.Entity
@javax.persistence.Table(name = "SYS_SJGL_HTRW")
@Setter
@Getter
public class SysSjglHtrw {

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 默认构造方法
	 */
	public SysSjglHtrw() {
	}

	/**
	 * 主键
	 */
	@Id
	@GeneratedValue(generator="idGenerator")
	@Column(name = "ID")
	private String id;
	/**
	 * 源库主键
	 */
	@Column(name = "YKZJ")
	private String ykzj;
	/**
	 * 更新时间
	 */
	@Column(name = "GXSJ")
	private String gxsj;
	/**
	 * 任务名称
	 */
	@Column(name = "RWMC")
	private String rwmc;
	/**
	 * 更新时限
	 */
	@Column(name = "GXSX")
	private String gxsx;
	/**
	 * 创建人单位名称
	 */
	@Column(name = "CJRDWMC")
	private String cjrdwmc;
	/**
	 * 增量时间戳
	 */
	@Column(name = "ZLSJC")
	private String zlsjc;
	/**
	 * 创建时间
	 */
	@Column(name = "CJSJ")
	private String cjsj;
	/**
	 * 执行状态@SYS_SJGL_ZXZT
	 */
	@Column(name = "ZXZT")
	private Integer zxzt;
	/**
	 * 创建人单位代码@SYS_COMMON_ORG
	 */
	@Column(name = "CJRDWDM")
	private String cjrdwdm;
	/**
	 * 创建人姓名
	 */
	@Column(name = "CJRXM")
	private String cjrxm;
	/**
	 * 标志时限
	 */
	@Column(name = "BZSX")
	private String bzsx;
	/**
	 * 定时
	 */
	@Column(name = "DS")
	private String ds;
	/**
	 * 最后更新时间
	 */
	@Column(name = "ZHGXSJ")
	private String zhgxsj;
	/**
	 * 创建人代码@SYS_COMMON_USER
	 */
	@Column(name = "CJRDM")
	private String cjrdm;
	/**
	 * 监测频率
	 */
	@Column(name = "JCPL")
	private String jcpl;
	/**
	 * 有效性@SYS_COMMON_LJPD
	 */
	@Column(name = "YXX")
	private String yxx;
	/**
	 * 任务类别@SYS_SJGL_HTRWLB
	 */
	@Column(name = "RWLB")
	private String rwlb;
	/**
	 * 排序
	 */
	@Column(name = "PX")
	private BigDecimal px;
	/**
	 * 扩展信息;JSON格式
	 */
	@Column(name = "KZXX")
	private String kzxx;
	/**
	 * 主键集合
	 */
	@Column(name = "IDS")
	private String ids;
}
