package cn.benma666.sjzt;

/**
 * 数据载体执行器
 * @param <T> 载体对象
 */
public interface SjztExecRunnable<T> {
    /**
     * 执行方法，执行完成会回收该客户端
     * @param clent 客户端
     */
    Object exec(T clent) throws Exception;
}
