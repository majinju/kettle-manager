package cn.benma666.sjzt;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 数据世界实体
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(value = {ElementType.METHOD, ElementType.FIELD,ElementType.TYPE})
public @interface SjsjEntity {
    /**
     * 字段业务类别
     * @return 类别代码
     */
    SjsjField value() default SjsjField.mrz;
}
