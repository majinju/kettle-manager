package cn.benma666.sjzt;

import cn.benma666.exception.MyException;

/**
 * 数据载体不支持文件大小异常
 */
public class SjztBzcwjdxExecption extends MyException {

    /**
     * Creates a new instance of ExcelReadException.
     */
    public SjztBzcwjdxExecption() {
    }

    /**
     * Creates a new instance of ExcelReadException.
     * @param message 异常消息
     */
    public SjztBzcwjdxExecption(String message) {
        super(message);
    }
}
