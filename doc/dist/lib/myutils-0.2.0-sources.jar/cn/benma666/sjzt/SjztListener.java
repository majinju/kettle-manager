package cn.benma666.sjzt;

import cn.benma666.domain.SysSjglZnjh;
import cn.benma666.iframe.BasicObject;
import cn.benma666.iframe.InterfaceLog;

public class SjztListener extends BasicObject implements Runnable {
    /**
     * 交换配置
     */
    private final SysSjglZnjh znjhConfig;
    /**
     * 监听的数据载体
     */
    private final BasicSjzt sjzt;
    /**
     * 智能交换的任务体
     */
    private final InterfaceLog znjhJob;

    public SjztListener(SysSjglZnjh znjhConfig, InterfaceLog znjhJob) {
        this.znjhConfig = znjhConfig;
        this.znjhJob = znjhJob;
        sjzt = BasicSjzt.useSjzt(znjhConfig.getSrzt());
    }

    @Override
    public void run() {
        sjzt.sjztjt(znjhConfig,znjhJob);
    }
}
