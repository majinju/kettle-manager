package cn.benma666.sjzt.kafka;

import cn.benma666.sjzt.BasicFile;
import cn.benma666.sjzt.BasicSjzt;
import org.apache.kafka.clients.consumer.ConsumerRecord;

public class KafkaFile extends BasicFile {

    private String name;
    private ConsumerRecord<String, String> file;

    public KafkaFile(String parent, ConsumerRecord<String, String> file, BasicSjzt sjzt) {
        super(parent, sjzt);
        this.file = file;
        this.name = String.valueOf(file.offset());
    }


    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean isDirectory() {
        return false;
    }

    @Override
    public boolean isFile() {
        return true;
    }

    @Override
    public long lastModified() {
        return this.file.timestamp();
    }

    public ConsumerRecord<String, String> getFile() {
        return file;
    }
}
