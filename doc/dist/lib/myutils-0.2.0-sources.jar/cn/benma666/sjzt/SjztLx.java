package cn.benma666.sjzt;

import cn.benma666.sjzt.bdwj.Bdwj;
import cn.benma666.sjzt.fastdfs.FastDFS;
import cn.benma666.sjzt.ftp.Ftp;
import cn.benma666.sjzt.kafka.Kafka;
import cn.benma666.sjzt.mqtt.Mqtt;
import cn.benma666.sjzt.rabbit.RabbitMQ;
import lombok.Getter;

/**
 * 载体类型
 */
@Getter
public enum SjztLx {
    bdwj(Bdwj.class),
    ftp(Ftp.class),
    kafka(Kafka.class),
    rabbitmq(RabbitMQ.class),
    fastdfs(FastDFS.class),
    minio(Minio.class),
    mqtt(Mqtt.class),
    es(ES.class)
    ;
    /**
     * 该载体的操作类
     */
    private final Class<?> ztClass;
    SjztLx(Class<?> ztClass){
        this.ztClass = ztClass;
    }
}
