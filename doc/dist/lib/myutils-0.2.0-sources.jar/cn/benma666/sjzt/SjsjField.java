package cn.benma666.sjzt;

/**
 * 数据世界实体业务类别
 */
public enum SjsjField {
    /**
     * 默认值，字段名转大写就是枚举值
     */
    mrz,
    /**
     * 主键
     */
    id,
    /**
     * 有效性
     */
    yxx,
    /**
     * 排序
     */
    px,
    /**
     * 创建时间
     */
    cjsj,
    /**
     * 更新时间
     */
    gxsj,
    /**
     * 创建人姓名
     */
    cjrxm,
    /**
     * 创建人代码
     */
    cjrdm,
    /**
     * 创建人单位名称
     */
    cjrdwmc,
    /**
     * 创建人单位代码
     */
    cjrdwdm,
    /**
     * 对象代码
     */
    dxdm,
    /**
     * 权限码
     */
    authCode,
    /**
     * 处理类型
     */
    cllx
    ;
}
