package cn.benma666.sjzt.mqtt;

import lombok.Getter;

/**
 * Mqtt消息质量
 */
@Getter
public enum MqttQos {
    /**
     * 最多一次
     */
    ZDYC(0),
    /**
     * 至少一次
     */
    ZSYC(1),
    /**
     * 正好一次
     */
    ZHYC(2);
    private int code;
    MqttQos(int code){
        this.code=code;
    }
}
