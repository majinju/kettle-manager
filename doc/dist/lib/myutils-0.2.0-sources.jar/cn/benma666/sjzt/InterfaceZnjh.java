package cn.benma666.sjzt;

import cn.benma666.domain.SysSjglZnjh;
import cn.benma666.iframe.InterfaceLog;

/**
 * 智能交换接口
 */
public interface InterfaceZnjh {
    void znjh(SysSjglZnjh znjhConfig, InterfaceLog log, IFile file);
}
