package cn.benma666.constants;

import lombok.Getter;

/**
 * 字符集
 */
@Getter
public enum Charset {
    UTF_8("UTF-8"),
    GBK("GBK");
    private final String code;
    Charset(String code){
        this.code = code;
    }
}
