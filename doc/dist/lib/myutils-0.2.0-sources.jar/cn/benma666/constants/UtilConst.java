package cn.benma666.constants;

/**
 * 常量 <br/>
 * date: 2016年5月24日 下午7:18:51 <br/>
 * @author jingma
 * @version 0.2
 */
public class UtilConst implements UtilConstInstance{
}
