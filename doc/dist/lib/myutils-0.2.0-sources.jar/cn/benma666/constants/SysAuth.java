package cn.benma666.constants;

/**
 * 系统-权限
 */
public enum SysAuth {
    /**
     *  系统最高权限
     */
    QTQX_SYS,
    /**
     * 权限码-平台-管理员
     */
    KFZFW_GLY,
    /**
     * 权限码-平台-系统管理员
     */
    KFZFW_SYS,
    /**
     * 没有配置权限时则统一采用未授权对象的权限
     */
    QTQX_WSQDX
}
