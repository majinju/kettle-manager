/**
* Project Name:myutils
* Date:2019年4月22日
* Copyright (c) 2019, jingma All Rights Reserved.
*/

package cn.benma666.iframe;

import cn.benma666.constants.UtilConst;
import cn.benma666.domain.SysSjglBhsc;
import cn.benma666.exception.MyException;
import cn.benma666.myutils.DateUtil;
import cn.benma666.sjzt.Db;
import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;

/**
 * 自增id <br/>
 * date: 2019年4月22日 <br/>
 * @author jingma
 * @version 0.2
 */
@Setter
@Getter
public class AutoId extends BasicObject{
    /**
     * 编号对象
     */
    private SysSjglBhsc bh = new SysSjglBhsc();
    /**
     * 获取最大变化的sql，初始化时使用
     */
    private String maxSql;
    /**
     * 自增缓存
     */
    private static JSONObject cache = CacheFactory.use(AutoId.class.getSimpleName());

    /**
    * 通过传入的sql获取初始值
    * @param maxSql 编号类别
    */
    public AutoId(String maxSql) {
        this.maxSql = maxSql;
    }

    /**
     * @param bh 编号对象
     */
    public AutoId(SysSjglBhsc bh) {
        this.bh = bh;
    }

    /**
     * 设置自增缓存
     * @param name 名称
     * @param ai 自增对象
     */
    public static void setCache(String name,AutoId ai){
        cache.put(name,ai);
    }

    /**
     * 获取缓存的自增对象
     * @param name 名称
     * @return 缓存的自增对象
     */
    public static AutoId use(String name){
        Object ai = cache.get(name);
        if(ai==null){
            throw new MyException("没有该自增对象："+name);
        }
        return (AutoId) ai;
    }
    /**
    * 下一个值 <br/>
    * @author jingma
    */
    public synchronized long next(){
        if(bh.getDqz()==0){
            if(maxSql!=null){
                String[] arr = Db.parseDictExp(maxSql, UtilConst.DEFAULT);
                assert arr != null;
                bh.setDqz(db(arr[0]).queryInt(arr[1]));
            }else if(bh.getBhlb()!=null){
                bh = db().lambdaQuery(SysSjglBhsc.class)
                        .andEq(SysSjglBhsc::getBhlb, bh.getBhlb()).singleSimple();
                if (bh == null) {
                    throw new MyException("编号类别不存在：" + bh);
                }
            }
        }
        bh.setDqz(bh.getDqz()+bh.getDzl());
        if(bh.getDqz()>=bh.getZdz()){
            bh.setDqz(bh.getCsz());
        }
        if(bh.getBhlb()!=null){
            bh.setGxsj(DateUtil.getGabDate());
            //每次都要更新，避免异常停止后重复
            sqlManager().updateTemplateById(bh);
        }
        return bh.getDqz();
    }
    /**
    * 下一个值 <br/>
    * @author jingma
    * @param length 补全位数
    * @return 用0补全的字符串
    */
    public String next(int length){
        return String.format("%0"+length+"d", next());
    }

}
