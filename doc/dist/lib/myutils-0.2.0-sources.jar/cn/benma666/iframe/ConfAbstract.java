/**
* Project Name:myutils
* Date:2021年9月14日
* Copyright (c) 2021, jingma All Rights Reserved.
*/

package cn.benma666.iframe;

/**
 * 配置接口 <br/>
 * date: 2021年9月14日 <br/>
 * @author jingma
 * @version 0.2
 */
public abstract class ConfAbstract<T> {
    /**
    * 自定义配置对象
    */
    protected T config;
    /**
     * Creates a new instance of ConfInterface.
     */
    public ConfAbstract() {
    }
    public ConfAbstract(T config) {
        super();
        this.config = config;
    }
    

    /**
     * @return config 
     */
    public T getConfig() {
        return config;
    }


    /**
     * @param config the config to set
     */
    public void setConfig(T config) {
        this.config = config;
    }


    /**
    * 获取配置 <br/>
    * @author jingma
    * @param key 键
    * @return 值
    */
    public abstract String getVal(String key);
}
