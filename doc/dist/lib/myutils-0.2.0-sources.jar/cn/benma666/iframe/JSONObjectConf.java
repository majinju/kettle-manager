/**
* Project Name:myutils
* Date:2021年9月14日
* Copyright (c) 2021, jingma All Rights Reserved.
*/

package cn.benma666.iframe;

import com.alibaba.fastjson.JSONObject;

/**
 * JSON配置 <br/>
 * date: 2021年9月14日 <br/>
 * @author jingma
 * @version 
 */
public class JSONObjectConf extends ConfAbstract<JSONObject> {

    /**
    * Creates a new instance of JSONObjectConf.
    * @param config
    */
    public JSONObjectConf(JSONObject config) {
        super(config);
    }

    /**
    * 
    * @see cn.benma666.iframe.ConfAbstract#getVal(java.lang.String)
    */
    @Override
    public String getVal(String key) {
        return config.getString(key);
    }

}
