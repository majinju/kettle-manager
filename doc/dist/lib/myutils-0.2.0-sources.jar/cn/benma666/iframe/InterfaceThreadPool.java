package cn.benma666.iframe;

/**
 * 线程池接口
 */
public interface InterfaceThreadPool {
    /**
     * 采用默认线程池执行任务
     * @param ra 待执行任务
     */
    void run(Runnable ra);
    /**
     * @return 线程池排队数量
     */
    int getQueueSize();
}
