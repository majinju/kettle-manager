package cn.benma666.iframe;

public interface InterfaceLog {
    //日志封装
    void debug(String msg, Object... appendLogArguments);
    void info(String msg, Object... appendLogArguments);
    void error(String msg, Object... appendLogArguments);

    void debug(String msg,Throwable t);
    void info(String msg,Throwable t);
    void error(String msg,Throwable t);
}
