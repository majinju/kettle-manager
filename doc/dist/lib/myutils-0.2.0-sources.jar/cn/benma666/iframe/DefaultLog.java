package cn.benma666.iframe;

/**
 * 日志默认实现
 */
public class DefaultLog extends BasicObject implements InterfaceLog {
    @Override
    public void debug(String msg, Object... appendLogArguments) {
        log.debug(msg,appendLogArguments);
    }

    @Override
    public void info(String msg, Object... appendLogArguments) {
        log.info(msg,appendLogArguments);
    }

    @Override
    public void error(String msg, Object... appendLogArguments) {
        log.error(msg,appendLogArguments);
    }

    @Override
    public void debug(String msg, Throwable t) {
        log.debug(msg,t);
    }

    @Override
    public void info(String msg, Throwable t) {
        log.info(msg,t);
    }

    @Override
    public void error(String msg, Throwable t) {
        log.error(msg,t);
    }
}
