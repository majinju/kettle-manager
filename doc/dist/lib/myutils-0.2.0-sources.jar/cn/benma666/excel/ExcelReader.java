package cn.benma666.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSONObject;

import java.util.Map;

/**
 * EXCEL文件读取
 */
public class ExcelReader extends AnalysisEventListener<JSONObject> {
    /**
     * 表头处理
     */
    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {

    }

    /**
     * 一行一行的数据处理
     */
    @Override
    public void invoke(JSONObject o, AnalysisContext analysisContext) {

    }

    /**
     * 读取异常处理
     */
    @Override
    public void onException(Exception exception, AnalysisContext context) throws Exception {
        super.onException(exception, context);
    }

    /**
     * 数据读取完后执行
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }
}
