package cn.benma666.excel;

import lombok.Builder;
import lombok.Data;

import java.io.InputStream;

/**
 * 图片连接转换key
 */
@Data
@Builder
public class ImageConverterKey {
    /**
     * 连接
     */
    private String lj;
    /**
     * 输入流
     */
    private InputStream in;
}
