/**
* Project Name:myutils
* Date:2016年7月27日
* Copyright (c) 2016, jingma All Rights Reserved.
*/

package cn.benma666.crypt;

import com.alibaba.druid.filter.config.ConfigTools;


/**
 * druid对密码加密解密采用的方法 <br/>
 * date: 2016年7月27日 <br/>
 * @author jingma
 * @version 
 */
public class DruidCrypt {
    
    /**
    * 加密<br/>
    * @param pwd 待加密的密码
    * @throws Exception
    */
    public static String[] encrypt(String pwd) throws Exception {
        String[] result = new String[2];
        String[] arr = ConfigTools.genKeyPair(512);
        result[0] = ConfigTools.encrypt(arr[0], pwd);
        result[1] = arr[1];
        return result;
    }
    /**
    * 解密 <br/>
    * @param crypt 待解密
    * @param pk 公钥
    * @return
    * @throws Exception 
    */
    public static String decrypt(String crypt,String pk) throws Exception{
        return ConfigTools.decrypt(ConfigTools.getPublicKey(pk),crypt);
    }

}
