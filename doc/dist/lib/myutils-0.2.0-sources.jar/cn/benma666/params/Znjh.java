package cn.benma666.params;

import cn.benma666.domain.BasicBean;
import lombok.Getter;
import lombok.Setter;

/**
 * 智能交换
 */
@Setter
@Getter
public class Znjh extends BasicBean {
    /**
     * 执行的sql
     */
    private String sql;
    /**
     * 开始点
     */
    private String start;
    /**
     * 结束点
     */
    private String end;
    /**
     * 穿透调用的目标节点
     */
    private String mbjd;
    /**
     * 穿透调用的用户
     */
    private String user;
    /**
     * 应用
     */
    private String app;
    /**
     * 调用地址
     */
    private String url;
}
