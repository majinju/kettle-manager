package cn.benma666.params;

import cn.benma666.domain.BasicBean;
import cn.benma666.iframe.MyParams;
import cn.benma666.params.other.Dcsjycl;
import com.alibaba.fastjson.JSONObject;
import lombok.*;

/**
 * 其他参数
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Other extends BasicBean {
    /**
     * 原始请求参数,将原始请求参数克隆备份一份，可能会用到，如：跨网请求需要原始请求参数
     */
    private MyParams ysParams;
    /**
     * 原始请求表单参数备份
     */
    private JSONObject yobj;
    /**
     * 导出数据预处理对象
     */
    private Dcsjycl dcsjycl;
}
