package cn.benma666.params.other;

import cn.benma666.domain.BasicBean;
import lombok.*;

import java.util.List;

/**
 * 导出数据预处理参数
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Dcsjycl extends BasicBean {
    /**
     * 表头
     */
    private List<List<String>> header;
    /**
     * 数据
     */
    private List<List<Object>> data;
    /**
     * 字段列表
     */
    private List<String> zdlist;
    /**
     * 增加行高
     */
    @Builder.Default
    private Boolean zjhg = false;

}
