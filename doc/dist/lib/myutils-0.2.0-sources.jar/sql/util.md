说明：工具类中的基础sql

getDate14
===
* 获取十四位时间
```sql
select ${globalUse("util.expDate14")} ${globalUse("util.expDefaultFrom")}
```

findTyzdMrsql
===
* 获取统一字典-默认sql
```sql
select t.#{globalUse('util.expField',{"field":"dm"\})},t.mc,t.upnode,t.px,#{globalUse('util.expConcatWs',{"list":["t.ms","t.jp","t.qp"]\})} as search_key,kzxx
from sys_sjgl_tyzd t
where t.zdlb=#{yobj.zdlb} and t.yxx='1'
```

findSjzt
===
* 获取数据载体
```sql
select * from sys_sjgl_sjzt where yxx='1' and dm = #{p1}
```

findTyzdLbsql
===
* 获取统一字典-类别查询sql
```sql
select lbsql,cache,sjdj from sys_sjgl_tyzd t
where t.zdlb='SYS_COMMON_ZDLB' and yxx='1' and t.dm=#{yobj.zdlb}
```

findTyzdSjlb
===
* 获取统一字典-数据列表
```sql
select * from (
    ${sql.defaultSql}
    ) t1
order by px,dm
```

findTyzdSjx
===
* 获取统一字典-数据项
```sql
select * from (
    ${sql.defaultSql}
    ) t1
-- @ where(){
    -- @ if(su.isNotBlank(yobj.dm)){
        and dm=#{yobj.dm}
    -- @}
    -- @ if(su.isNotBlank(yobj.mc)){
        and (dm=#{yobj.mc} or mc=#{yobj.mc})
    -- @}
-- @}
```

findTyzdSjss
===
* 获取统一字典-数据搜索
```sql
select
-- @pageTag(){
   *
-- @}
from (
    ${sql.defaultSql}
    ) t1
-- @ where(){
    -- @if(sys.jqss=='1'){
        and (dm=#{sys.searchKey} or mc=#{sys.searchKey} or search_key=#{sys.searchKey})
    -- @}else if(su.isNotBlank(sys.searchKey)){
        and lower(#{globalUse('util.expConcatWs',{"list":["dm","mc","search_key"]\})})
        like lower(#{'%'+sys.searchKey+'%'})
    -- @}
    -- @if(su.isNotBlank(yobj.dm)){
        and dm=#{yobj.dm}
    -- @}
    -- @if(su.isNotBlank(sys.ids)){
        and dm=#{join(sys.ids)}
    -- @}
    -- @if(su.isNotBlank(yobj.mc)){
        and mc=#{yobj.mc}
    -- @}
-- @}
-- @pageIgnoreTag(){
   order by px,dm
-- @}
```

findBhsc
===
* 获取编号生成对象
```sql
select * from sys_sjgl_bhsc t where t.bhlb=#{p1} and t.yxx=#{p2}
```

updateBhsc
===
* 更新编号生成对象
```sql
update sys_sjgl_bhsc t set t.dqz=#{p1} where t.bhlb=#{p2} and t.yxx=#{p3}
```
