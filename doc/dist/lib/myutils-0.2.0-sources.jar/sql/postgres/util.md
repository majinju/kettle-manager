
expField
===
* 字段
```sql
`${field}`
```

expDateToStr14
===
* 时间对象转十四位时间
```sql
to_char(${dateObj},'yyyyMMddhh24miss')
```

expDate14
===
* 获取十四位时间
```sql
${use("expDateToStr14",{"dateObj":"current_timestamp"\})}
```

expStr14ToDate
===
* 十四位时间转时间对象
```sql
to_timestamp(dateStr,'yyyyMMddhh24miss')
```

expDefaultFrom
===
* 默认from，如查询时间等系统数据时会使用
```sql
 
```

expConcatWs
===
* 字符串拼接
```sql
CONCAT_WS('',${su.strJoin(list,",")})
```