tab_comments
===
* 查询表的注释
```sql
SELECT remarks comments
FROM v_catalog.all_tables t where schema_name = #{owner} and table_name=#{tableName}
```

cols_info
===
* 查询表的列信息
```sql
SELECT column_name zddm,column_name zdms,split_part(data_type,'(',1) zdlx,data_type_length zdcd,'' xzmrz,'' sfzj
FROM v_catalog.columns c
where  table_name = #{owner}
  and c.table_schema = #{owner}
union all
SELECT column_name zddm,column_name zdms,split_part(data_type,'(',1) zdlx,data_type_length zdcd
FROM v_catalog.view_columns c
where  table_name = #{owner}
  and c.table_schema = #{owner}
```

