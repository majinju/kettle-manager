说明：工具类中的基础sql

expField
===
* 字段
```sql
"${su.upperCase(field)}"
```

expDateToStr14
===
* 时间对象转十四位时间
```sql
to_char(${dateObj},'YYYYMMDDHH24MISS')
```

expDate14
===
* 获取十四位时间
```sql
${use("expDateToStr14",{"dateObj":"sysdate"\})}
```

expStr14ToDate
===
* 十四位时间转时间对象
```sql
to_date(dateStr,'YYYYMMDDHH24MISS')
```

expDefaultFrom
===
* 默认from，如查询时间等系统数据时会使用
```sql
from dual
```

expConcatWs
===
* 字符串拼接
```sql
${su.strJoin(list,"||")}
```
