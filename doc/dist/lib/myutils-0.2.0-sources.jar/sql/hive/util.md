说明：工具类中的基础sql

expField
===
* 字段
```sql
`${field}`
```

expDateToStr14
===
* 时间对象转十四位时间
```sql
from_unixtime(${dateObj},'yyyyMMddHHmmss')
```

expDate14
===
* 获取十四位时间
```sql
${use("expDateToStr14",{"dateObj":"unix_timestamp()"\})}
```

expStr14ToDate
===
* 十四位时间转时间对象
```sql
unix_timestamp(dateStr,'yyyyMMddHHmmss')
```

expDefaultFrom
===
* 默认from，如查询时间等系统数据时会使用
```sql

```

expConcatWs
===
* 字符串拼接
```sql
CONCAT_WS('',${su.strJoin(list,",")})
```