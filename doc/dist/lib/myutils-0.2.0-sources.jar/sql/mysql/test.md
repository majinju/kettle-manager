create_table_test
===
* 新建表
```sql
CREATE TABLE SYS_SJGL_TYZD (
                               ID VARCHAR(32) DEFAULT (REPLACE(UUID(),'-','')) NOT NULL,
                               CJSJ VARCHAR(14) DEFAULT (date_format(now(), '%Y%m%d%H%I%S')),
                               GXSJ VARCHAR(14) DEFAULT (date_format(now(), '%Y%m%d%H%I%S')),
                               YXX VARCHAR(8) DEFAULT '1',
                               PX bigint DEFAULT 99999,
                               KZXX VARCHAR(4000) DEFAULT '```json
{}
```',
                               CJRXM VARCHAR(64),
                               CJRDM VARCHAR(32),
                               CJRDWMC VARCHAR(256),
                               CJRDWDM VARCHAR(32),
                               DM VARCHAR(100),
                               MC text,
                               MS text,
                               JP text,
                               QP text,
                               ZDLB VARCHAR(100),
                               BZZD VARCHAR(100),
                               LBSQL text,
                               SJLY VARCHAR(300),
                               UPNODE VARCHAR(100),
                               CACHE VARCHAR(10) DEFAULT '1',
                               SJDJ VARCHAR(10) DEFAULT '3'
)
```

insert_table_test
===
* 插入数据
```sql
insert into SYS_SJGL_TYZD(dm,mc) values(#{dm},#{mc})
```

select_table_test
===
* 查询数据
```sql
select * from SYS_SJGL_TYZD t where 1=1
```


drop_table_test
===
* 删除表
```sql
drop table SYS_SJGL_TYZD
```