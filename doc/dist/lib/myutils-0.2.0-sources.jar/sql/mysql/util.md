说明：工具类中的基础sql

expField
===
* 字段
```sql
`${field}`
```

expNvl
===
* 如果第一个为空则取第二个值，否则取第一个
```sql
IFNULL(${val1},${val2})
```

expDateToStr14
===
* 时间对象转十四位时间
```sql
date_format(${dateObj},'%Y%m%d%H%i%S')
```

expDate14
===
* 获取十四位时间
```sql
${use("expDateToStr14",{"dateObj":"now()"\})}
```

expStr14ToDate
===
* 十四位时间转时间对象
```sql
str_to_date(dateStr,'%Y%m%d%H%I%S')
```

expDefaultFrom
===
* 默认from，如查询时间等系统数据时会使用
```sql

```

expConcatWs
===
* 字符串拼接
```sql
CONCAT_WS('',${su.strJoin(list,",")})
```

createTable
===
* 创建表
```sql
CREATE TABLE `${sjdx.jtdx+yobj.hz}` (
/*
var zd;
for(ent in fields){
    var field = ent.value;
    zd = " `"+field.zddm+"` ";
    if(!su.contains(field.zdywlb,"99")){
        zd = zd+dict.zdDmByMc("SYS_SJGL_ZDLX_MYSQL",field.zdlx);
        if(field.zdlx=='VARCHAR2'){
            zd = zd+"("+field.zdcd+")";
        }
        if(field.bjbt=='1'){
            //必填处理
            zd = zd+" NOT NULL ";
        }
        if(field.xzmrz=='sys_guid()'){
            //唯一键
            zd = zd+" DEFAULT (replace(uuid(),_utf8mb4'-',_utf8mb4'')) ";
        }else if('ElDatePicker'==field.kjlx&&!isEmpty(field.xzmrz)){
            //时间
            zd = zd+" DEFAULT (date_format(now(),_utf8mb4'%Y%m%d%H%i%S')) ";
        }else if(field.zdlx=='VARCHAR2'&&!isEmpty(field.xzmrz)){
            //基础类型
            zd = zd+" DEFAULT '"+field.xzmrz+"' ";
        }else if(field.zdlx=='NUMBER'&&!isEmpty(field.xzmrz)){
            //基础类型
            zd = zd+" DEFAULT "+field.xzmrz+" ";
        }
        if(!isEmpty(field.zdmc)){
            zd = zd+" COMMENT '"+field.zdmc+(isEmpty(field.zdzdlb)?"":"@"+field.zdzdlb)+';'+field.zdms+"'";
        }
        zd = zd+",";
*/
    ${zd}
/*
    }
}
*/
    PRIMARY KEY (`${sjdx.zjzd}`) USING BTREE
) COMMENT='${sjdx.dxmc}'

```
