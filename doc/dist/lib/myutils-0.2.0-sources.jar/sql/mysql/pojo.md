tab_comments
===
* 查询表的注释
```sql
SELECT
    t.TABLE_COMMENT comments
FROM
    information_schema.TABLES t
WHERE t.TABLE_SCHEMA=#{owner}
    and t.TABLE_NAME = #{tableName}
```

cols_info
===
* 查询表的列信息
```sql
select a.COLUMN_NAME zddm,
       a.COLUMN_COMMENT zdms,
       a.DATA_TYPE zdlx,
       a.CHARACTER_MAXIMUM_LENGTH zdcd,
       a.COLUMN_DEFAULT xzmrz,
       a.COLUMN_KEY sfzj
from information_schema.COLUMNS a
where a.table_name = #{tableName}
  and a.TABLE_SCHEMA = #{owner}
```

