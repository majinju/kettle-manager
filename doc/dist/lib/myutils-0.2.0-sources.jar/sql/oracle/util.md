说明：工具类中的基础sql

expField
===
* 字段
```sql
"${su.upperCase(field)}"
```

expNvl
===
* 如果第一个为空则取第二个值，否则取第一个
```sql
nvl(${val1},${val2})
```

expDateToStr14
===
* 时间对象转十四位时间
```sql
to_char(${dateObj},'YYYYMMDDHH24MISS')
```

expDate14
===
* 获取十四位时间
```sql
${use("expDateToStr14",{"dateObj":"sysdate"\})}
```

expStr14ToDate
===
* 十四位时间转时间对象
```sql
to_date(dateStr,'YYYYMMDDHH24MISS')
```

expDefaultFrom
===
* 默认from，如查询时间等系统数据时会使用
```sql
from dual
```

expConcatWs
===
* 字符串拼接
```sql
${su.strJoin(list,"||")}
```

createTable
===
* 创建表
```sql
/*
var zd="";
for(ent in fields){
    var field = ent.value;
    if(!su.contains(field.zdywlb,"99")){
        zd = zd+',\r\n\t"'+su.upperCase(field.zddm)+'" ';
        zd = zd+field.zdlx;
        if(field.zdlx=='VARCHAR2'){
            zd = zd+"("+field.zdcd+")";
        }
        if(field.xzmrz=='sys_guid()'){
            //唯一键
            zd = zd+" DEFAULT sys_guid() ";
        }else if('ElDatePicker'==field.kjlx&&!isEmpty(field.xzmrz)){
            //时间
            zd = zd+" DEFAULT to_char(sysdate,'yyyymmddhh24miss') ";
        }else if(field.zdlx=='NUMBER'&&!isEmpty(field.xzmrz)){
            //基础类型
            zd = zd+" DEFAULT "+field.xzmrz+" ";
        }else if(field.zdlx=='VARCHAR2'&&!isEmpty(field.xzmrz)){
            //基础类型
            zd = zd+" DEFAULT '"+su.replace(field.xzmrz,"\n","")+"' ";
        }
        if(field.bjbt=='1'){
            //必填处理
            zd = zd+" NOT NULL ";
        }
        zd = zd;
    }
}
zd = su.substring(zd,2);
*/
CREATE TABLE ${sjdx.jtdx+yobj.hz} (
${zd}
);--
/*
zd = "";
for(ent in fields){
    var field = ent.value;
    if(!su.contains(field.zdywlb,"99")){
*/
comment on column ${sjdx.jtdx+yobj.hz}."${su.upperCase(field.zddm)}" is '${field.zdmc+(isEmpty(field.zdzdlb)?"":"@"+field.zdzdlb)};${su.replace(field.zdms,"\n","")}';--
/*
    }
}
*/
comment on table ${sjdx.jtdx+yobj.hz} is '${sjdx.dxmc}';--
alter table ${sjdx.jtdx+yobj.hz} add constraint PK_${sjdx.jtdx+yobj.hz} primary key (${sjdx.zjzd})

```
