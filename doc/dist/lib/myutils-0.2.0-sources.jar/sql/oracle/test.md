create_table_test
===
* 新建表
```sql
create table SYS_ZD_TYZD
(
  ID         VARCHAR2(40) default sys_guid() not null,
  DM         VARCHAR2(100),
  MC         VARCHAR2(4000),
  MS         VARCHAR2(4000),
  PX         NUMBER default 99999,
  JP         VARCHAR2(4000),
  QP         VARCHAR2(4000),
  ZDLB       VARCHAR2(100),
  BZZDLB     VARCHAR2(100),
  LBSQL      VARCHAR2(500),
  CREATEDATE VARCHAR2(14) default to_char(sysdate,'yyyymmddhh24miss'),
  ETLDATE    VARCHAR2(14) default to_char(sysdate,'yyyymmddhh24miss'),
  SJLY       VARCHAR2(300),
  ISDEL      VARCHAR2(10) default '0',
  UPNODE     VARCHAR2(100),
  CACHE      VARCHAR2(10) default '1'
)
```

insert_table_test
===
* 插入数据
```sql
insert into SYS_ZD_TYZD(dm,mc) values(#{dm},#{mc})
```

select_table_test
===
* 查询数据
```sql
select * from SYS_ZD_TYZD t where 1=1
```


drop_table_test
===
* 查询数据
```sql
drop table SYS_ZD_TYZD
```