说明：数据世界-方言

jlgxZqx
===
* 权限代码调整时，联动调整子权限的代码
```sql
  update sys_qx_qxxx t set t.dm=replace(t.dm,#{obj.dm+"_"},#{yobj.dm+"_"}),t.gxsj=#{globalUse("util.expDate14")}
  where t.dm like #{obj.dm+"\\_%"} escape '\'
```

wlscZqx
===
* 无效的数据且允许物理删除，删除对应的子权限
```sql
  delete from sys_qx_qxxx t where t.dm like #{yobj.dm+"\\_%"} escape '\' and t.yxx='0'
```

wlscZqxsq
===
* 无效的数据且允许物理删除，删除对应的子权限的授权
```sql
  delete from sys_qx_jsqxgl t
  where exists (
      select 1 from sys_qx_jsxx js where js.id=t.js and js.dm like #{yobj.dm+"\\_%"} escape '\'
      ) and t.yxx='0'
```

ljscZqx
===
* 有效数据逻辑删除子权限
```sql
  update sys_qx_qxxx t set t.yxx='0',t.gxsj=#{globalUse("util.expDate14")} where  t.dm like #{yobj.dm+"\\_%"} escape '\' and t.yxx='1'
```

ljscZqxsq
===
* 有效数据逻辑删除子权限的授权
```sql
  update sys_qx_jsqxgl t set t.yxx='0',t.gxsj=#{globalUse("util.expDate14")}
  where exists (
      select 1 from sys_qx_jsxx js where js.id=t.js and js.dm like #{yobj.dm+"\\_%"} escape '\'
      ) and t.yxx='1'
```

gxjsZqx
===
* 更新角色子权限代码
```sql
  update sys_qx_jsxx t set t.dm=replace(t.dm,#{obj.dm+"_"},#{yobj.dm+"_"}),t.gxsj=#{globalUse("util.expDate14")}
  where t.dm like #{obj.dm+"\\_%"} escape '\'
```

qx-fzjl
===
* 权限-记录复制
```sql
  INSERT INTO sys_qx_qxxx (
  	fqx,
  	dm,
  	mc,
  	ms,
  	lx,
  	ssyy,
  	zcsjd,
  	bz,
  	dzlx,
  	dkfs,
  	sjdx,
  	dz,
  	tb,
  	px,
  	yxx,
  	kzxx,
  	cjsj,
  	cjrxm,
  	cjrdm,
  	cjrdwmc,
  	cjrdwdm,
  	mcjp,
  	mcqp,
  	tptb
  ) SELECT
  fqx,
  replace(dm,#{yobj.dm},#{yobj.dm++'COPY'}) dm,
  mc,
  ms,
  lx,
  ssyy,
  zcsjd,
  bz,
  dzlx,
  dkfs,
  sjdx,
  dz,
  tb,
  px,
  yxx,
  kzxx,
  cjsj,
  cjrxm,
  cjrdm,
  cjrdwmc,
  cjrdwdm,
  mcjp,
  mcqp,
  tptb
  FROM
  	sys_qx_qxxx t
  	where t.dm like #{yobj.dm+'\\_%'} escape '\' or t.dm = #{yobj.dm}
```


qx-fzjl-gxfqx
===
* 权限-记录复制-更新父权限
```sql
  update sys_qx_qxxx t set
  t.fqx=(select id from sys_qx_qxxx q where q.yxx='1' and q.dm=SUBSTRING_INDEX(t.dm,'_', length(t.dm)- length(REPLACE(t.dm,"_","")))),
  t.gxsj=#{globalUse("util.expDate14")}
  where t.dm like #{yobj.dm+'COPY'+"\\_%"} escape '\'
```
