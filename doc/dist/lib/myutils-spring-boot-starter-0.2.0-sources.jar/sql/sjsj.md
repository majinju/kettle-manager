说明：数据世界

findSjdx
===
* 获取数据对象
```sql
select t.*,qx.dm auth_code from sys_sjgl_sjdx t
left join sys_qx_qxxx qx on qx.sjdx=t.id and qx.yxx='1'
where t.yxx='1'
-- @ if(!isEmpty(sys.dlsjdxid)){
  and t.dxdm=#{sys.dlsjdxid}
-- @} else if(!isEmpty(sys.dlsjdxdm)){
  and t.dxdm=#{sys.dlsjdxdm}
-- @} else if(!isEmpty(sys.authCode)){
  and qx.dm=#{sys.authCode}
-- @} else if(!isEmpty(sjdx.id)){
  and t.id=#{sjdx.id}
-- @} else if(!isEmpty(sjdx.dxdm)){
  and t.dxdm=#{sjdx.dxdm}
-- @} else{
  and t.id=''
-- @}
```

updateSjzd
===
* 更新数据字段
```sql
update sys_sjgl_sjzd t1 set yxx='0',gxsj=#{globalUse("util.expDate14")}
where t1.yxx='1'
  -- @ if(!isEmpty(sys.ids)&&sys.ids.~size>0){
  and t1.sjdx in (#{join(sys.ids)})
  -- @ }else{
  and exists (select 1 from sys_sjgl_sjdx t
    -- @ where(){
              ${sql.whereStr} and t1.sjdx=t.id
    -- @ }
    )
-- @}
```

deleteSjzd
===
* 删除数据字段
```sql
delete from sys_sjgl_sjzd t1
where yxx='0'
  -- @ if(!isEmpty(sys.ids)&&sys.ids.~size>0){
  and t1.sjdx in (#{join(sys.ids)})
  -- @ }else{
  and exists (select 1 from sys_sjgl_sjdx t
      -- @ where(){
          ${sql.whereStr} and t1.sjdx=t.id
      -- @ }
      )
  -- @}
```

findUser
===
* 获取用户信息 -- or lxdh=#{yhdm} or yhyx=#{yhdm}
```sql
select * from sys_qx_yhxx where yxx='1'
-- @ if(!isEmpty(id)){
    and id=#{id}
-- @}else if(!isEmpty(sfzh)){
    and sfzh=#{sfzh}
-- @}else if(!isEmpty(wxyhid)){
    and wxyhid=#{wxyhid}
-- @}else if(!isEmpty(sqm)){
    and sqm=#{sqm}
-- @}else if(!isEmpty(yhdm)){
    and (id=#{yhdm} or sfzh=#{yhdm} or yhdm=#{yhdm} or wxyhid=#{yhdm})
-- @}else{
    and id=''
-- @}
```

updateUser
===
* 更新用户信息
```sql
update sys_qx_yhxx t
set t.gxsj = #{globalUse("util.expDate14")}
-- @ if(!isEmpty(p1.wxyhid)){
    , wxyhid=#{p1.wxyhid}
-- @}
where yxx='1'
-- @ if(!isEmpty(p1.id)){
    and id=#{p1.id}
-- @}else{
    and id=''
-- @}
```

findJgxx
===
* 获取机构信息
```sql
select * from sys_qx_jgxx where yxx='1'
-- @ if(!isEmpty(ssjg)){
    and id=#{ssjg}
-- @}else{
    and id=''
-- @}
```

findJsxx
===
* 获取角色信息
```sql
select js.dm js from sys_qx_yhjsgl t
inner join sys_qx_jsxx js on js.id=t.js
where t.yxx='1'
-- @ if(!isEmpty(user.id)){
    and t.yh=#{user.id}
-- @}else{
    and t.id=''
-- @}
```

findYhqxxx
===
* 用户权限信息
```sql
  select distinct qx.dm, qx.mc
  from sys_qx_qxxx qx
  inner join sys_qx_jsqxgl jq
  on qx.id = jq.qx
  and jq.yxx = '1'
  inner join sys_qx_jsxx js
  on js.id = jq.js
  and js.yxx = '1'
  where qx.yxx = '1'
  -- @if(has(user)){
	-- @if(user.zdlb!="PC"){
	  and qx.zcsjd = '1'
	-- @}
  and (js.dm in (
  'ADMIN_DLYH_LSYH'
  -- @if(user.yhdm!='lsyh'){
  ,'ADMIN_DLYH'
  -- @}
  )
  -- @for(e in user.jsMap){
  or js.dm like #{e.key+'%'}
  -- @}
  )
  -- @}
```

findYhDxQxYs
===
* 用户相关的对象和权限代码的映射
```sql
  select #{globalUse("util.expNvl",{"val1":"dx.dxdm","val2":"qx.dz"\})} dxdm,max(qx.dm) qxm
  from sys_qx_qxxx qx
  inner join sys_qx_jsqxgl jq
  on qx.id = jq.qx
  and jq.yxx = '1'
  inner join sys_qx_jsxx js
  on js.id = jq.js
  and js.yxx = '1'
  left join sys_sjgl_sjdx dx
  on qx.sjdx=dx.id
  where qx.yxx = '1'
    -- @if(user.zdlb!="PC"){
      and qx.zcsjd = '1'
    -- @}
  and (js.dm in (
  'ADMIN_DLYH_LSYH'
  -- @if(user.yhdm!='lsyh'){
  ,'ADMIN_DLYH'
  -- @}
  )
  -- @for(e in user.jsMap){
  or js.dm like #{e.key+'%'}
  -- @}
  )
  and (qx.sjdx is not null or (qx.dz is not null and qx.dzlx='01'))
  group by #{globalUse("util.expNvl",{"val1":"dx.dxdm","val2":"qx.dz"\})}
```

insertJsqx
===
* 插入角色权限关联信息
```sql
  insert into sys_qx_jsqxgl( cjrxm, cjrdm, cjrdwmc, cjrdwdm, js, qx)
  values (#{user.cjrxm}, #{user.cjrdm}, #{user.cjrdwmc}, #{user.cjrdwdm},#{yobj.js}, #{sql.changeNode.id})
```

qxsqJsqx
===
* 将取消的授权改为无效
```sql
  update sys_qx_jsqxgl t set t.yxx='0',t.gxsj=#{globalUse("util.expDate14")}
  where t.js=#{yobj.js} and t.qx=#{sql.changeNode.id} and t.yxx='1'
```

updateSjzt
===
* 更新数据载体
```sql
  update sys_sjgl_sjzt t set t.ljc=#{p1},t.yhm=#{p2},t.lx=#{p3},
    t.gxsj=#{globalUse("util.expDate14")}
  -- @where(){
    -- @if(isNotEmpty(p4)){
        and t.dm=#{p4}
    -- @}else{
        and 1=2
    -- @}
  -- @}
```
