
gxwddm
===
* 更新文档代码
```sql
update sys_sjgl_grbj t
set t.dm=#{globalUse('util.expConcatWs',{"list":["(select dm from (select * from sys_sjgl_grbj) t1 where t1.id=t.sjbj)","'_'","t.id"]\})}
where t.sjbj is not null and t.id=#{yobj.id}
```
