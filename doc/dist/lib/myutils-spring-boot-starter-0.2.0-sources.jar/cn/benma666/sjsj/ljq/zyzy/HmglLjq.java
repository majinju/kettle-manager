/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.zyzy;

import cn.benma666.domain.SysQxYhxx;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import com.alibaba.fastjson.JSONObject;

/**
 * 比对核查-号码<br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
public class HmglLjq extends DefaultLjq {
    @Override
    public Result save(MyParams myParams) {
        if(!myParams.sys().getYzdjl()){
            //插入时，主证件号码为空则自动用核查证件号码填充
            JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
            if(StringUtil.isBlank(yobj.getString("zzjhm"))){
                yobj.put("zzjhm", yobj.getString("hczjhm"));
                yobj.put("zzjlx", yobj.getString("hczjlx"));
            }
            if(StringUtil.isBlank(yobj.getString("gkdw"))){
                //管控单位
                SysQxYhxx user = (SysQxYhxx) myParams.get(KEY_USER);
                yobj.put("gkdw", user.getJgxx().getId());
            }
            if(StringUtil.isBlank(yobj.getString("ssxm"))){
                //支持在对象中配置所属项目
                yobj.put("ssxm", sjdx.getKzxxObj().getString("$.zyzy.ssxm"));
            }
            myParams.put(KEY_YOBJ,yobj);
        }
        return super.save(myParams);
    }
}
