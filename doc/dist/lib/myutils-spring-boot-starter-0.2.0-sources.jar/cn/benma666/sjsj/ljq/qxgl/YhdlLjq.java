/**
 * Project Name:sjgl
 * Date:2018年12月16日
 * Copyright (c) 2018, jingma All Rights Reserved.
 */

package cn.benma666.sjsj.ljq.qxgl;

import cn.benma666.domain.SysQxYhxx;
import cn.benma666.domain.SysSjglSjzd;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.DateUtil;
import cn.benma666.myutils.HttpUtil;
import cn.benma666.myutils.JsonUtil;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjsj.web.LjqManager;
import cn.benma666.sjsj.web.UserManager;
import cn.benma666.sjzt.Db;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.util.TypeUtils;
import org.beetl.sql.core.SqlId;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * 用户登录拦截器 <br/>
 * date: 2018年12月16日 <br/>
 *
 * @author jingma
 */
@Component("SYS_QX_YHXX_MRDL")
@Scope("prototype")
@ConditionalOnProperty(value = "benma666.login.default-login")
public class YhdlLjq extends DefaultLjq {

    public static final String BASIC = "basic";

    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict("SYS_QX_YHXX");
        return r;
    }
    /**
     * 用户登陆
     * @return 处理结果
     */
    public Result yhdl(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        //失败次数
        SysQxYhxx user = myParams.getObject(KEY_USER, SysQxYhxx.class);
        int dlsbcs = TypeUtils.castToInt(valByDef(user.get("dlsbcs"),0));
        if(dlsbcs>=valByDef(Conf.getUtilConfig().getLogin().getDlsbcs(),5)){
            //限制时长为会话时长，关闭浏览器重新进入其实是可以的，这好像不太好样，后续考虑采用ip限制
            return failed("你登录失败次数过多，请稍后再试");
        }
        //用户账户密码登陆
        if (DateUtil.getGabDate().compareTo(Conf.getVal("sys.yxq")) > 0
                && !"sys".equals(yobj.getString("yhdm"))) {
            return failed("系统版本过旧，请升级后使用");
        }
        if (StringUtil.isBlank(yobj.getString("yhmm")) || StringUtil.isBlank(yobj.getString("yhdm"))) {
            return dlsb(failed("用户名或密码为空"),myParams);
        }
        if(user.getYhdm().equals(yobj.getString("yhdm"))){
            return xtjcxx(myParams, user,false);
        }
        JSONObject jsonObj = db().findFirst(SqlId.of("sjsj", "findUser"), yobj);
        if (jsonObj == null) {
            return dlsb(failed("没有找到该用户" , yobj.getString("yhdm")),myParams);
        }
        SysQxYhxx yhxx = jsonObj.toJavaObject(SysQxYhxx.class);
        String yhmm;
        // 获取用户信息基础参数对象
        JSONObject yhxxParams = LjqManager.jcxxByDxdm("SYS_QX_YHXX");
        //将用户输入的密码加密
        yhmm = StringUtil.desEnByField(yobj.getString("yhmm"),yhxxParams.getObject("$.fields.yhmm", SysSjglSjzd.class));
        if (!yhxx.getYhmm().equals(yhmm)) {
            return dlsb(failed("密码不正确"),myParams);
        }
        if (StringUtil.isNotBlank(yhxx.getXzip())
                && !user.getClientIp().matches(yhxx.getXzip())) {
            return dlsb(failed("你未不在授权的ip范围内登录"),myParams);
        }
        user = UserManager.findUser(myParams,false);
        if(StringUtil.isNotBlank(yobj.getString("projectCode"))){
            //传了项目代码，进行微信绑定操作
            //微信登陆
            JSONObject r = HttpUtil.doJosnByFrom(Conf.getVal("wx.api.base.url") + "/sns/jscode2session",
                    Conf.getVal("wx.api.login.params." + yobj.getString("projectCode")) + myParams.getString($_SYS_TOKEN));
            if (r.getIntValue("errcode") != 0) {
                return failed("微信接口异常："+r.getString("errmsg"));
            }
            log.debug("从微信获取的用户信息："+r.toJSONString());
            //微信用户唯一标志
            String wxyhid = r.getString("openid");
            user.setWxyhid(wxyhid);
            db().update(SqlId.of("sjsj","updateUser"), Db.buildMap(user));
        }
        return xtjcxx(myParams, user);
    }
    public Result dlsb(Result r,MyParams myParams){
        SysQxYhxx user = myParams.getObject(KEY_USER, SysQxYhxx.class);
        int dlsbcs = TypeUtils.castToInt(valByDef(user.get("dlsbcs"),0));
        user.set("dlsbcs",dlsbcs+1);
        return r;
    }
    /**
     * 转发用户信息，用于第三方系统自动登录
     */
    public Result zfyhxx(MyParams myParams){
        String url = UserManager.doDesEncryptUrl(myParams.getString("$.yobj.url"),
                myParams.getString("$.yobj.projectCode"),
                myParams.getString("$.user.sfzh"));
        Result r = success("成功", url);
        r.setCode(HttpStatus.FOUND.value());
        return r;
    }
    /**
     * 微信登陆
     * @return 处理结果
     */
    public Result wxdl(MyParams myParams) {
        SysQxYhxx oldUser = myParams.getObject(KEY_USER,SysQxYhxx.class);
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        SysQxYhxx user;
        //微信登陆
        JSONObject r = HttpUtil.doJosnByFrom(Conf.getVal("wx.api-base-url",
                "https://api.weixin.qq.com")
                + "/sns/jscode2session",Conf.getVal("wx.api-login-params."
                + yobj.getString("projectCode")) + oldUser.getToken());
        if (r.getIntValue("errcode") != 0) {
            return failed("微信接口异常："+r.getString("errmsg"));
        }
        log.debug("从微信获取的用户信息："+r.toJSONString());
        //微信用户唯一标志
        String wxyhid = r.getString("openid");
        try {
            if(wxyhid.equals(oldUser.getWxyhid())){
                return xtjcxx(myParams, oldUser,false);
            }
            yobj.put("wxyhid", wxyhid);
            user = UserManager.findUser(myParams,true);
            user.set("wxLogin", r);
            return xtjcxx(myParams, user);
        } catch (MyException e) {
            //系统中还没有该微信用户
            oldUser.set("wxLogin", r);
            //返回临时用户
            return xtjcxx(myParams, oldUser,false);
        }
    }
    /**
     * 用户退出
     * @return 处理结果
     */
    public Result yhtc(MyParams myParams) {
        SysQxYhxx oldUser = myParams.getObject(KEY_USER,SysQxYhxx.class);
        return UserManager.removeUser(oldUser);
    }

    private Result xtjcxx(MyParams myParams, SysQxYhxx user) {
        return xtjcxx(myParams,user,true);
    }
    /**
     * @param myParams 参数
     * @param user 最新用户信息
     * @return 系统基础信息
     */
    private Result xtjcxx(MyParams myParams, SysQxYhxx user,boolean adduser) {
        if(adduser){
            myParams.put(KEY_USER, user);
            UserManager.addUser(myParams.getString($_SYS_TOKEN), user);
        }
        String model = valByDef(myParams.getString("$.yobj.model"), BASIC);
        if(BASIC.equals(model)){
            JSONObject data = new JSONObject();
            JsonUtil.copy(data, myParams, $_SYS_TOKEN);
            return success("登陆成功",data);
        }else {
            return super.xtjcxx(myParams);
        }
    }
}
