/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.qxgl;

import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 访问日志拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
@Component("SYS_LOG_FWZR")
@Scope("prototype")
public class FwrzLjq extends DefaultLjq {
    @Override
    public Result select(MyParams myParams) {
        return super.select(myParams);
    }
}
