/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.qxgl;

import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjsj.myutils.MyTransactional;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjsj.web.UserManager;
import com.alibaba.fastjson.JSONObject;
import org.beetl.sql.core.SqlId;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 角色信息拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
@Component
@Scope("prototype")
public class JsxxLjq extends DefaultLjq {
    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict("SYS_QX_JSXX");
        return r;
    }

    @Override
    @MyTransactional
    public Result update(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        String dm = yobj.getString("dm");
        JSONObject obj = myParams.getJSONObject(KEY_OBJ);
        if( StringUtil.isNotBlank(dm)){
            //权限代码调整时，联动调整子权限的代码
            db().update(SqlId.of("dialect.sjsj","gxjsZqx"), myParams);
//            UserManager.flushUserQxxx();
        }
        return super.update(myParams);
    }
    /**
     * 刷新用户权限
     * @return 处理结果
     */
    public Result sxyhqx(MyParams myParams) {
        UserManager.flushUserQxxx(myParams);
        return success("刷新用户权限成功");
    }
}
