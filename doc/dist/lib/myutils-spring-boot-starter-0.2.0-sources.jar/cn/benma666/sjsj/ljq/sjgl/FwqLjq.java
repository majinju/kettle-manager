/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;

/**
 * 服务器拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
public class FwqLjq extends ScjkrwLjq{
    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict("SYS_QX_FWQ");
        return r;
    }
}
