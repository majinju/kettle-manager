/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.domain.SysSjglFile;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.PageInfo;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.util.TypeUtils;

import java.util.List;

/**
 * 文件管理拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
public class FileLjq extends DefaultLjq {

    protected Result wlscByYxx(MyParams myParams) {
        myParams.set("$.page.totalRequired",false);
        //删除物理删除记录的对应的文件
        List<SysSjglFile> list = ((PageInfo<JSONObject>)select(myParams).getData()).getList(SysSjglFile.class);
        int success = 0;
        int failed = 0;
        for(SysSjglFile fileObj:list){
            if(TypeUtils.castToBoolean(fileObj.getYxx())){
                //有效的过滤掉，只对已经逻辑删除过的文件进行物理删除
                continue;
            }
            try {
                if(fileObj.delete()){
                    success++;
                }else {
                    failed++;
                }
            }catch (Exception e){
                log.debug("删除文件失败",e);
                failed++;
            }
        }
        Result result = super.wlscByYxx(myParams);
        result.addMsg("成功删除原始文件数："+success);
        if(failed>0){
            result.addMsg("失败数："+failed);
        }
        return result;
    }
}
