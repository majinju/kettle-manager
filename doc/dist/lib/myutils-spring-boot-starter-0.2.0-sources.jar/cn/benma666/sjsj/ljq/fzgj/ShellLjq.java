package cn.benma666.sjsj.ljq.fzgj;

import cn.benma666.crypt.DesUtil;
import cn.benma666.domain.SysQxFwq;
import cn.benma666.exception.BusinessException;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import com.alibaba.druid.util.Utils;
import com.alibaba.fastjson.JSONObject;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/**
 * shell命令执行拦截器
 */
public class ShellLjq extends DefaultLjq {
    /**
     * 服务器解密秘钥
     */
    private static final String fwqPassword = Conf.getUtilConfig().getFwqEjmm();

    @Override
    public Result insert(MyParams myParams) {
        // 执行命令
        String ml = myParams.getString("$.yobj.ml");
        String[] mls = myParams.getString("$.yobj.ml").split("\n");
        // 服务器id
        String fwqid = myParams.getString("$.yobj.fwq");
        // 返回结果
        StringBuilder resStr = new StringBuilder();
        try {
            // 如果不是本机
            if (isBlank(fwqid)) {
                Runtime runtime = Runtime.getRuntime();
                for (String s : mls) {
                    if (!isBlank(s)) {
                        Process process = runtime.exec(s);
                        resStr.append("==================>").append(s).append("\n");
                        resStr.append(Utils.read(process.getInputStream()));
                        resStr.append(Utils.read(process.getErrorStream()));
                        resStr.append("\n");
                        process.destroy();
                    }
                }
            } else {
                // 查询服务器信息
                SysQxFwq fwq = sqlManager().lambdaQuery(SysQxFwq.class).andEq(SysQxFwq::getId, fwqid).singleSimple();
                JSch jsch = new JSch();
                Session session = jsch.getSession(fwq.getYhm(), fwq.getIp(), StringUtil.isBlank(fwq.getYcdk()) ? 22 : Integer.parseInt(fwq.getYcdk()));
                java.util.Properties config = new java.util.Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                if (StringUtil.isBlank(fwq.getMm())) {
                    throw new MyException("服务器解密秘钥为空");
                }
                // 解密密码
                String pwd = DesUtil.decrypt(fwq.getMm(), fwqPassword);
                session.setPassword(pwd);
                session.connect(600000);
                ChannelExec process = (ChannelExec) session.openChannel("exec");
                process.setCommand(ml);
                process.connect();
                resStr.append("==================>").append(ml).append("\n");
                resStr.append(Utils.read(process.getInputStream()));
                resStr.append(Utils.read(process.getErrStream()));
                resStr.append(Utils.read(process.getExtInputStream()));
                resStr.append("\n");
                process.disconnect();
            }
        } catch (Exception e) {
            throw new BusinessException("命令执行异常",e);
        }
        JSONObject res = new JSONObject();
        res.put("zxjg", resStr);
        res.put("ml", "");
        return success("操作成功", res);
    }
}
