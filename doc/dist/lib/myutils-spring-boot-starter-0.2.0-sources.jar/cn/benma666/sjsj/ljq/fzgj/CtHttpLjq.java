package cn.benma666.sjsj.ljq.fzgj;

import cn.benma666.domain.SysSjglFile;
import cn.benma666.exception.BusinessException;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.HttpByOk;
import cn.benma666.myutils.HttpUtil;
import cn.benma666.myutils.WebUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.vo.WjscVo;
import com.alibaba.druid.util.Utils;
import com.alibaba.fastjson.JSONObject;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.apache.http.client.methods.HttpPost;

import java.io.IOException;
import java.io.InputStream;

/**
 * 穿透http请求
 */
public class CtHttpLjq extends DefaultLjq {

    @Override
    public Result insert(MyParams myParams) throws MyException {
        JSONObject rep = new JSONObject();
        Result r = doHttp(myParams, null, null,rep);
        JSONObject data = new JSONObject();
        data.put(Result.DATA,r.getData());
        data.put("repHeards",rep);
        r.setData(data);
        return r;
    }

    @Override
    protected Result upload(MyParams myParams, SysSjglFile file, byte[] byteArr) throws Exception {
        return doHttp(myParams, file, byteArr,null);
    }
    @Override
    public Result download(MyParams myParams) {
        JSONObject rep = new JSONObject();
        byte[] resByte;
        try {
            resByte = Utils.readByteArray(getInputStream(myParams, null, null, rep));
        } catch (IOException e) {
            throw new BusinessException("穿透http请求结果流读取失败",e);
        }
        String filename;
        String filetype = "";
        String fieldValue = rep.getString("Content-Disposition");
        if (fieldValue == null || !fieldValue.contains("filename=")) {
            String url = myParams.getString("$.yobj.url");
            String[] s = url.split("/");
            filename = s[s.length - 1];
        } else {
            filename = fieldValue.substring(fieldValue.indexOf("filename=") + 10, fieldValue.length() - 1);
        }
        String[] s1 = filename.split("\\.");
        filetype = s1[s1.length - 1];
        SysSjglFile file1 = new SysSjglFile();
        file1.setWjm(filename);
        file1.setWjlx(filetype);
        return super.resultFile(resByte, file1);
    }

    public Result doHttp(MyParams myParams, SysSjglFile file, byte[] byteArr,JSONObject rep) {
        String qqbm = valByDef(myParams.getString("$.yobj.qqbm"), HttpUtil.DEFAULT_QQBM);
        try {
            String resStr = new String(Utils.readByteArray(getInputStream(myParams,file,byteArr,rep)), qqbm);
            return success("请求成功", resStr);
        } catch (IOException e) {
            throw new BusinessException("穿透http请求结果流读取失败",e);
        }

    }
    public InputStream getInputStream(MyParams myParams, SysSjglFile file, byte[] byteArr,JSONObject rep) {
        HttpUtil http = new HttpUtil(HttpByOk.getInstance());
        // 上传文件类接口的文件参数名
        String fileKey = valByDef(myParams.getString("$.yobj.fileKey"), "file");
        // 请求方式
        String qqfs = valByDef(myParams.getString("$.yobj.qqfs"), HttpPost.METHOD_NAME);
        // 请求编码
        String qqbm = valByDef(myParams.getString("$.yobj.qqbm"), HttpUtil.DEFAULT_QQBM);
        // 超时时长
        Integer cssc = myParams.getInteger("$.yobj.cssc");
        cssc = cssc == null?HttpUtil.DEFAULT_CSSC:cssc;
        // 请求头
        JSONObject rp = valByDef(myParams.getJSONObject("$.yobj.headers"), new JSONObject());
        // 请求参数
        JSONObject params = valByDef(myParams.getJSONObject("$.yobj.params"), new JSONObject());
        // 请求地址
        String url = myParams.getString("$.yobj.url");

        if (isBlank(url)) {
            throw new MyException("请求地址不能为空");
        }
        // 设置请求方式
        rp.put(HttpUtil.REQUEST_METHOD, qqfs);
        // 设置参数格式
        if (isBlank(rp.getString(HttpUtil.CONTENT_TYPE))) {
            rp.put(HttpUtil.CONTENT_TYPE, WebUtil.CONTENTTYPE_APPLICATION_JSON);
        }
        // 设置上传文件
        if (!isBlank(file)) {
            rp.put(HttpUtil.CONTENT_TYPE,"multipart/form-data");
            String type = DictManager.zdMcByDm("SYS_COMMON_XZTLX", file.getWjlx());
            if (file.getWjlx().equals(type)) {
                type = "application/octet-stream";
            }
            RequestBody requestBody = RequestBody.create(byteArr, MediaType.parse(type));
            WjscVo wjscVo = new WjscVo(file.getWjm(), requestBody);
            params.put(fileKey, wjscVo);
        }
        // 发起http请求
        return http.getInputStream(url, params, qqbm, cssc, rp, rep);
    }

}
