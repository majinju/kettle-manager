/**
* Project Name:myservice
* Date:2019年9月19日
* Copyright (c) 2019, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;

/**
 * 应用管理拦截器 <br/>
 * date: 2019年9月19日 <br/>
 * @author jingma
 * @version 0.1
 */
public class AppLjq extends ScjkrwLjq {
    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict("SYS_QX_APP");
        return r;
    }
}
