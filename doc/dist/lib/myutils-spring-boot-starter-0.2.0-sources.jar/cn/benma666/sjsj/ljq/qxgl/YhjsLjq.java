/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.qxgl;

import cn.benma666.sjsj.web.DefaultLjq;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 用户角色拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
@Component("SYS_QX_YHJSGL")
@Scope("prototype")
public class YhjsLjq extends DefaultLjq {
}
