package cn.benma666.sjsj.ljq.fzgj;

import cn.benma666.exception.MyException;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.main.Mmjjm;
import cn.benma666.sjsj.web.DefaultLjq;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 加解密
 */
@Component("SYS_FZGJ_JJM")
@Scope("prototype")
public class JjmLjq extends DefaultLjq {
    @Override
    public Result insert(MyParams myParams) throws MyException {
        return Mmjjm.jjm(myParams);
    }
}
