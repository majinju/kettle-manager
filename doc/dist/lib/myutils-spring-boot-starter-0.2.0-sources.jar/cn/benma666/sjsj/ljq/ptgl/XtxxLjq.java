package cn.benma666.sjsj.ljq.ptgl;

import cn.benma666.domain.SysPtglXtxx;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjsj.web.XtxxWebSocket;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 系统消息拦截器
 */
@Component("SYS_PTGL_XTXX")
@Scope("prototype")
public class XtxxLjq extends DefaultLjq {
    /**
     * 消息推送
     */
    public Result xxts(MyParams myParams) throws MyException {
        return XtxxWebSocket.sendMsg(myParams.getObject(KEY_YOBJ,
                SysPtglXtxx.class),getUser(myParams));
    }
}
