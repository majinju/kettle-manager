/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 数据字段拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
@Component("SYS_SJGL_SJZD")
@Scope("prototype")
public class SjzdLjq extends DefaultLjq {
    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict("SYS_SJGL_SJZD");
        return r;
    }

}
