/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.crypt.DesUtil;
import cn.benma666.dict.Zdlb;
import cn.benma666.domain.SysSjglSjzt;
import cn.benma666.iframe.CacheFactory;
import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.FileUtil;
import cn.benma666.sjzt.BasicSjzt;
import com.alibaba.fastjson.JSONObject;

import java.io.IOException;
import java.util.List;

/**
 * 数据载体拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
public class SjztLjq extends ScjkrwLjq {
    @Override
    public Result save(MyParams myParams) {
        Result r = super.save(myParams);
        DictManager.clearDict(Zdlb.SYS_COMMON_SJZT.name());
        CacheFactory.use("sjzt").remove((isBlank(myParams.get("$.yobj.dm"))
                ?myParams.get("$.obj.dm"):myParams.get("$.yobj.dm"))+"_json");
        return r;
    }
    /**
     * 测试数据载体
     * @return 测试结果
     */
    public Result cszt(MyParams myParams) {
        myParams.set("$.page.totalRequired",false);
        //最多操作50000，暂时写死，后面可以改为配置
        myParams.set("$.page.pageSize",50000);
        List<SysSjglSjzt> ztList = select(myParams).getPageList(SysSjglSjzt.class);
        int tgs = 0;
        StringBuilder wtg = new StringBuilder();
        for(SysSjglSjzt obj:ztList){
            SysSjglSjzt u = new SysSjglSjzt();
            obj.setMm(DesUtil.decrypt(obj.getMm(),BasicSjzt.getSjztEjmm()));
            Result r = BasicSjzt.csztSjzt(obj);
            if(r.isStatus()) {
                tgs++;
                u.setZt("1");
            } else {
                u.setZt("2");
                wtg.append(obj.getMc()).append(":").append(r.getMsg()).append(",");
            }
            u.setId(obj.getId());
            sqlManager().updateTemplateById(u);
        }
        Result r = success("测试了"+ztList.size()+"个数据源，测试成功"+tgs+"个");
        if(wtg.length()>0){
            r.addMsg("未通过载体如下："+wtg.substring(0,wtg.length()-1));
        }
        return r;
    }

    @Override
    public Result insert(MyParams myParams) {
        yclSjzt(myParams);
        return super.insert(myParams);
    }

    /**
     * 预处理数据载体
     * @param myParams 相关参数
     */
    private void yclSjzt(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        JSONObject obj = myParams.getJSONObject(KEY_OBJ);
        if(obj==null){
            obj = yobj;
        }else {
            obj.putAll(yobj);
        }
        String ljc = yobj.getString("ljc");
        String lx = obj.getString("lx");
        switch (lx) {
            case "bdwj":
                //本地文件都以/结尾
                if(!isBlank(ljc)){
                    yobj.put("ljc", FileUtil.getPath(ljc));
                }
                break;
            case "ftp":
            default:
                break;
        }
        success("预处理成功", yobj);
    }

    @Override
    public Result update(MyParams myParams) {
        yclSjzt(myParams);
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        JSONObject obj = myParams.getJSONObject(KEY_OBJ);
        obj.putAll(yobj);
        String dbdm = obj.getString("dm");
        if(CacheFactory.use("sjzt").containsKey(dbdm)&&BasicSjzt.csztSjzt(obj
                .toJavaObject(SysSjglSjzt.class)).isStatus()){
            //修改已经加载的数据源，此处进行关闭
            try {
                BasicSjzt.useSjzt(dbdm).close();
            } catch (IOException e) {
                log.debug("数据载体关闭失败："+dbdm,e);
            }
        }
        return super.update(myParams);
    }

}
