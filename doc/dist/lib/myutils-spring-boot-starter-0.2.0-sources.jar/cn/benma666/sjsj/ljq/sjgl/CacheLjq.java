/**
 * Project Name:sjgl
 * Date:2018年12月16日
 * Copyright (c) 2018, jingma All Rights Reserved.
 */

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.iframe.CacheFactory;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.PageInfo;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 缓存拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.2
 */
public class CacheLjq extends DefaultLjq {

    @Override
    public Result select(MyParams myParams) {
        PageInfo<JSONObject> page = new PageInfo<>();
        List<JSONObject> list = new ArrayList<>();
        page.setList(list);
        Map<String, JSONObject> cache = CacheFactory.getCacheMap();
        for (String key:cache.keySet()){
            JSONObject obj = new JSONObject();
            obj.put("key",key);
            obj.put("size",cache.get(key).size());
            list.add(obj);
        }
        return success("缓存查询成功",page);
    }

    /**
     * 清除缓存
     */
    public Result qchc(MyParams myParams) {
        List<String> ids = myParams.sys().getIds();
        if(ids==null){
            return failed("请选择要清除的缓存");
        }
        int keyNum = ids.stream().mapToInt(CacheFactory::clear).sum();
        return success("清除缓存成功，缓存种数："+ids.size()+"，累加缓存键数："+keyNum);
    }

    /**
     * 缓存的key列表
     */
    public Result hcKeys(MyParams myParams){
        JSONArray ids = myParams.getJSONArray($_SYS_IDS);
        if(ids==null){
            return failed("请选择缓存");
        }
        JSONObject hc = CacheFactory.use(ids.getString(0));
        return success("缓存键列表",hc.keySet());
    }
    /**
     * 缓存完整值，谨慎调用，可能会很大
     */
    public Result hcObj(MyParams myParams){
        JSONArray ids = myParams.getJSONArray($_SYS_IDS);
        if(ids==null){
            return failed("请选择缓存");
        }
        JSONObject hc = CacheFactory.use(ids.getString(0));
        return success("缓存完整值",hc);
    }

    /**
     * 缓存的值基于key
     */
    public Result hcValByKey(MyParams myParams){
        JSONObject hc = CacheFactory.use(myParams.getString("$.yobj.key"));
        return success("缓存的值基于key",hc.get(myParams.getString("$.yobj.hckey")));
    }
}
