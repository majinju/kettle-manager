package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.domain.SysSjglFile;
import cn.benma666.domain.SysSjglZnjh;
import cn.benma666.exception.BusinessException;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.PageInfo;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.DateUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjzt.BasicSjzt;
import cn.benma666.sjzt.bdwj.BdwjFile;
import cn.benma666.sjzt.IFile;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 文件管理拦截器，用于操作本地文件、ftp等文件类数据载体上的文件
 */
@Component("SYS_SJGL_WJGL")
@Scope("prototype")
public class WjglLjq extends DefaultLjq {
    @Override
    public Result select(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        //根目录
        String parent = yobj.getString("parent");
        if(isBlank(parent)){
            parent = FXG;
        }else if(parent.contains("##")){
            parent = parent.replace("##",FXG);
        }
        if(isBlank(yobj.getString("sjzt"))){
            return failed("必须选择数据载体");
        }
        //选择数据载体
        BasicSjzt sjzt = BasicSjzt.useSjzt(yobj.getString("sjzt"));
        try {
            SysSjglZnjh znjh = new SysSjglZnjh();
            znjh.setSrml(parent);
            znjh.setBlbhml(yobj.getBoolean("blbhml"));
            znjh.setDgbl(yobj.getBoolean("dgbl"));
            znjh.setJtwjzz(yobj.getString("jtwjzz"));
            List<IFile> list = sjzt.listFiles(znjh);
            //获取分页对象
            PageInfo<JSONObject> page = myParams.getObject(KEY_PAGE,PageInfo.class);
            List<JSONObject> l = new ArrayList<>();
            JSONObject row;
            for (IFile file : list){
                row = new JSONObject();
                l.add(row);
                row.put("id",file.getParent()+"##"+file.getName());
                row.put("name",file.getName());
                row.put("parent",file.getParent());
                row.put("directory",file.isDirectory());
                row.put("length",file.length());
                row.put("lastModified", DateUtil.dateToStr14(file.lastModified()));
            }
            page.setList(l);
            return success("获取文件列表成功",page);
        }catch (Exception e){
            throw new BusinessException("遍历目录失败："+parent,e);
        }
    }

    /**
     * 下载文件
     */
    public Result xzwj(MyParams myParams) {
        JSONArray ids = myParams.getJSONArray($_SYS_IDS);
        if(isBlank(ids)){
            return failed("请选择要下载的文件");
        }
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        String id = ids.getString(0);
        SysSjglFile file = new SysSjglFile();
        file.setWjlx(id.substring(id.lastIndexOf(".")+1));
        file.setWjm(id.substring(id.lastIndexOf("##")+2));
        file.setXzms(yobj.getBoolean("xzms")?2:1);
        BasicSjzt sjzt = BasicSjzt.useSjzt(yobj.getString("sjzt"));
        IFile f = new BdwjFile(yobj.getString("parent"),yobj.getString("name"),sjzt);
        try {
            return resultFile(f.getBytes(),file);
        } catch (Exception e) {
            throw new BusinessException("获取文件内容失败："+f.getAbsolutePath(),e);
        }
    }

    @Override
    public Result plsc(MyParams myParams) {
        JSONArray ids = myParams.getJSONArray($_SYS_IDS);
        if(isBlank(ids)){
            return failed("请选择要操作的文件");
        }
        BasicSjzt sjzt = BasicSjzt.useSjzt(myParams.getString("$.yobj.sjzt"));
        int num = 0;
        for (int i=0;i<ids.size();i++){
            String id = ids.getString(i);
            try {
                sjzt.delete(new BdwjFile(id.substring(0,id.indexOf("##")),
                        id.substring(id.indexOf("##")+2)));
                num++;
            } catch (Exception e) {
                throw new BusinessException("文件删除失败："+id,e);
            }
        }
        return success("成功删除文件："+num);
    }

    @Override
    public Result update(MyParams myParams) throws MyException {
        return failed("暂不支持");
    }

    @Override
    public Result insert(MyParams myParams) throws MyException {
        return failed("暂不支持");
    }
    public Result fzjl(MyParams myParams) throws MyException {
        return failed("暂不支持");
    }
}
