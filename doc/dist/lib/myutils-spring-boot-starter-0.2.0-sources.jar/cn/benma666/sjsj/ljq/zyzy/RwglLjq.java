/**
* Project Name:myservice
* Date:2020年7月15日
* Copyright (c) 2020, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.zyzy;

import cn.benma666.exception.MyException;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.StringUtil;
import cn.benma666.sjsj.web.DefaultLjq;
import com.alibaba.fastjson.JSONObject;

/**
 * 任务管理 <br/>
 * date: 2020年7月15日 <br/>
 * @author jingma
 * @version 0.1
 */
public class RwglLjq extends DefaultLjq {
    @Override
    public Result save(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        JSONObject kzxx = sjdx.getKzxxObj();
        //本系统为比对核查系统的一个子系统，本系统的数据都属于同一个固定项目
        myParams.set("$.yobj.ssxm", kzxx.getString("$.zyzy.ssxm"));
        myParams.set("$.yobj.id", StringUtil.getUUIDUpperStr());
        if(myParams.containsKey($_SYS_CSTCL+".数据文件")){
            //页面上传
            myParams.set($_SYS_CSTCL+".数据文件.yobj.ssrw",yobj.getString("id"));
        }else if(myParams.containsKey($_SYS_CSTCL+".号码列表")){
            //接口传输
            myParams.set($_SYS_CSTCL+".号码列表.yobj.ssrw",yobj.getString("id"));
        }else {
            throw new MyException("没有设置号码");
        }
        return super.save(myParams);
    }
}
