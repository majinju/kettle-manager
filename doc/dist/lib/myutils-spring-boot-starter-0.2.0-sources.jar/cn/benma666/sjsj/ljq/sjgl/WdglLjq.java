/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.constants.SysAuth;
import cn.benma666.domain.SysQxYhxx;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjsj.web.UserManager;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.beetl.sql.core.SqlId;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.net.HttpURLConnection;
import java.util.List;

/**
* 个人笔记展示 <br/>
* date: 2020年5月25日 <br/>
* @author jingma
* @version 0.1
*/
@Component("SYS_SJGL_GRBJ")
@Scope("prototype")
public class WdglLjq extends DefaultLjq {

    @Override
    public Result select(MyParams myParams) {
        Result r = super.select(myParams);
        SysQxYhxx user = getUser(myParams);
        List<JSONObject> list = r.getPageList(JSONObject.class);
        //移除无权限的笔记
        list.removeIf(obj -> !qxpdByBj(user, obj.getString("zt"), obj.getString("cjrdm"),
                obj.getString("cjrdwdm"), obj.getString("kjx")).isStatus()
        );
        if(myParams.getBooleanValue("$.yobj.wdxq")&&list.size()==1){
            JSONObject obj = list.get(0);
            db().update("update SYS_SJGL_GRBJ t set t.ydcs=(t.ydcs+1) where t.id=?",
                    obj.getString("id"));
        }
        r.set("$.data.list",list);
        return r;
    }

    @Override
    public Result save(MyParams myParams) {
        boolean isGxdm = isBlank(myParams.get("$.yobj.id")) || !isBlank(myParams.get("$.yobj.sjbj"));
        Result r = super.save(myParams);
        //更新代码字段
        if(isGxdm){
            db().update(SqlId.of("wdgl","gxwddm"),myParams);
        }
        return r;
    }

    /**
    * 权限判断-笔记 <br/>
    */
    public static Result qxpdByBj(SysQxYhxx user, String zt, String cjrdm, String cjrdwdm, String kjx) {
        //是否管理员
        if(UserManager.hasAuth(user, SysAuth.QTQX_SYS.name())){
            //管理员无限制
            return success("系统管理员");
        }
        Result r1 = failed("");
        r1.setCode(HttpURLConnection.HTTP_FORBIDDEN);
        //草稿状态，且非本人
        if("01".equals(zt)&&!cjrdm.equals(user.getId())){
            r1.setMsg("该文档还为发布，敬请期待发布");
        }
        //可见范围控制
        switch (kjx) {
        case "01":
            //仅自己
            if(!cjrdm.equals(user.getId())){
                r1.setMsg("该文档仅创建人可见");
            }
            break;
        case "02":
            //本单位
            if(!cjrdwdm.equals(user.getSsjg())){
                r1.setMsg("该文档仅创建人同单位人员可见");
            }
            break;
        case "03":
            //登陆用户
            if(UserManager.LSYH.equals(user.getYhdm())){
                r1.setMsg("该文档需要登录后才能查看");
            }
            break;
            //后续考虑支持授权访问，就是将笔记id作为权限编码加入权限管理，进行授权。
        default:
            //完全公开
        }
        if(StringUtils.isBlank(r1.getMsg())){
            //没有设置无权限消息，则是有权限
            r1 = success("有权限");
        }
        return r1;
    }
}
