/**
* Project Name:sjgl
* Date:2018年12月16日
* Copyright (c) 2018, jingma All Rights Reserved.
*/

package cn.benma666.sjsj.ljq.sjgl;

import cn.benma666.dict.Cllx;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.sjsj.myutils.MyTransactional;
import cn.benma666.sjsj.web.DefaultLjq;
import cn.benma666.sjzt.Db;
import com.alibaba.fastjson.JSONObject;
import org.jetbrains.annotations.NotNull;

/**
 * SQL执行拦截器 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 * @version 0.1
 */
public class SqlzxLjq extends DefaultLjq {
    @Override
    @MyTransactional
    public Result insert(MyParams myParams) {
        JSONObject yobj = myParams.getJSONObject(KEY_YOBJ);
        String zxsql = yobj.getString("zxsql");
        String zxfs = yobj.getString("zxfs");
        Db db = Db.use(yobj.getString("sjzt"));
        String[] sqlArr = zxsql.split(";");
        for (int i =0;i<sqlArr.length-1;i++){
            //前面的sql只能执行更新
            @NotNull Result r = zxsql(sqlArr[i], Cllx.update.name(), db);
            if(!r.isStatus()){
                r.addMsg("执行的sql："+sqlArr[i]);
                //失败直接返回
                return r;
            }
        }
        //替换为最后的sql
        zxsql = sqlArr[sqlArr.length-1];
        if(isBlank(zxfs)){
            zxfs = zxsql.toLowerCase().trim().startsWith("select")?Cllx.select.name():Cllx.update.name();
        }
        //最后一个sql的执行结果返回
        return zxsql(zxsql, zxfs, db);
    }

    @NotNull
    private Result zxsql(String zxsql, String zxfs, Db db) {
        try {
            long start = System.currentTimeMillis();
            JSONObject obj = new JSONObject();
            if(zxfs.equals(Cllx.select.name())){
                obj.put("zxjg", db.find(zxsql));
            }else{
                obj.put("zxjg", db.update(zxsql));
            }
            Result r = success("执行成功",obj);
            r.addMsg("耗时："+(System.currentTimeMillis()-start)+"毫秒");
            return r;
        } catch (Exception e) {
            log.debug("sql执行失败",e);
            return failed("执行失败："+e.getMessage());
        }
    }
}
