package cn.benma666.sjsj.znjh;

import cn.benma666.constants.UtilConst;
import cn.benma666.dict.Yxzt;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.PageInfo;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.DateUtil;
import cn.benma666.myutils.HttpUtil;
import cn.benma666.myutils.JsonUtil;
import cn.benma666.sjsj.job.BasicJob;
import cn.benma666.sjsj.web.LjqManager;
import cn.benma666.sjsj.web.UserManager;
import cn.benma666.sjzt.Db;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.util.TypeUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * 基础输入处理器
 */
@Component("jcsr")
@Scope("prototype")
public class JcsrClq extends BasicClq{
    @Override
    public void run() {

    }

    @Override
    public List<JSONObject> plcl(MyParams myParams, List<JSONObject> list, BasicJob job) throws Exception {
        // 增量字段
        String zlzd = myParams.sjdx().getZlzd();
        if(!isBlank(job.getZlsjc())){
            //任务中有增量则设置，没有则采用默认
            myParams.set("$.znjh.start",job.getZlsjc());
        }
        String start = myParams.getString("$.znjh.start");
        if(!isBlank(start)&&start.length()==14){
            //开始值长度为14时才设置当前时间为结束
            myParams.set("$.znjh.end", DateUtil.getGabDate());
        }
        PageInfo page = myParams.getObject(UtilConst.KEY_PAGE, PageInfo.class);
        if(!isBlank(zlzd)){
            //设置按增量字段排序
            page.setOrderBy(zlzd);
            myParams.set("$.yobj."+zlzd, Arrays.asList(start,myParams.getString("$.znjh.end")));
        }
        if (isBlank(myParams.get("$.page.pageSize"))) {
            //设置页大小
            page.setPageSize(TypeUtils.castToInt(valByDef(Conf.getUtilConfig().getZnjh().getPageSize(), 1000)));
        }
        //数据传输不进行总量统计
        page.setTotalRequired(false);
        myParams.put(UtilConst.KEY_PAGE,page);
        String sruser = valByDef(myParams.znjh().getUser(), Conf.getUtilConfig().getZnjh().getUser());
        //分为sql、本地方法、接口
        if(!isBlank(myParams.getString("$.znjh.sql"))){
            //sql场景
            String[] sqlArr = Db.parseDictExp(myParams.getString("$.znjh.sql"));
            page = db(sqlArr[0]).queryPage(page, sqlArr[1], myParams);
        }else if(!isBlank(myParams.getString("$.znjh.app"))){
            //接口场景
            String url = UserManager.doDesEncryptUrl(valByDef(myParams.getString("$.znjh.url"),
                            Conf.getVal("benma666.znjh.url")),
                    myParams.getString("$.znjh.app"),sruser);
            Result result = Result.parse(HttpUtil.doJosnByJson(url, myParams.toJSONString()));
            if(!result.isStatus()){
                throw new MyException("接口请求异常："+result);
            }
            page = result.getData(PageInfo.class);
        }else {
            //本地方法场景
            MyParams jcxx = LjqManager.jcxx(JsonUtil.clone(myParams),UserManager.findUser(sruser));
            //合并参数
            JsonUtil.mergeJSONObject(jcxx,myParams);
            Result result = LjqManager.data(jcxx);
            if(!result.isStatus()){
                throw new MyException("方法执行异常："+result);
            }
            page = result.getData(PageInfo.class);
        }
        list = page.getList(JSONObject.class);
        //读取量
        int dql = list.size();
        job.setDql(dql);
        int cfl = 0;
        //主键字段
        String zjzd = valByDef(myParams.getString("$.sjdx.zjzd"),"id");
        //移除与上次重复的数据
        if (!isBlank(job.getIds()) && !isBlank(start)) {
            JSONArray ids = JSON.parseArray(job.getIds());
            Iterator<JSONObject> iter = list.iterator();
            while (iter.hasNext()) {
                JSONObject n = iter.next();
                if(start.equals(n.getString(zlzd))){
                    if (ids.contains(n.getString(zjzd))) {
                        //时间一样、id一样则算重复
                        iter.remove();
                        cfl++;
                    }
                }else {
                    //数据按增量字段递增排序
                    break;
                }
            }
        }
        job.putLzrz(dql-cfl,cfl,0);
        if (list.size() == 0) {
            job.setJg(Yxzt.SUCCESS.getCode());
            job.info("没查询到数据");
            return null;
        }
        //设置新的增量时间戳
        job.setZlsjc(list.get(list.size()-1).getString(zlzd));
        //设置新的主键集合
        List<String> ids = new ArrayList<>();
        for (int i=list.size()-1;i>=0;i--) {
            JSONObject jsonObject = list.get(i);
            if (jsonObject.getString(zlzd).equals(job.getZlsjc())) {
                ids.add(jsonObject.getString(zjzd));
            }else {
                break;
            }
        }
        job.setIds(ids);
        return list;
    }
}
