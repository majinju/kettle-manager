package cn.benma666.sjsj.znjh;

import cn.benma666.constants.UtilConst;
import cn.benma666.dict.Yxzt;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.HttpUtil;
import cn.benma666.myutils.JsonUtil;
import cn.benma666.sjsj.job.BasicJob;
import cn.benma666.sjsj.web.LjqManager;
import cn.benma666.sjsj.web.UserManager;
import com.alibaba.fastjson.JSONObject;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 基础输出处理器
 */
@Component("jcsc")
@Scope("prototype")
public class JcscClq extends BasicClq{
    @Override
    public void run() {

    }

    @Override
    public List<JSONObject> plcl(MyParams myParams, List<JSONObject> list, BasicJob job) throws Exception {
        if (list == null) return null;
        //本地plbc方法、接口
        Result result;
        String scuser = valByDef(myParams.znjh().getUser(),Conf.getUtilConfig().getZnjh().getUser());
        if(!isBlank(myParams.znjh().getApp())){
            //接口场景
            String url = UserManager.doDesEncryptUrl(valByDef(myParams.znjh().getUrl(),
                    Conf.getUtilConfig().getZnjh().getUrl()),
                    myParams.znjh().getApp(),scuser);
            //设置数据
            myParams.sys().setEditTableData(list);
            result = Result.parse(HttpUtil.doJosnByJson(url, myParams.toJSONString()));
            if(!result.isStatus()){
                throw new MyException("接口请求异常："+result);
            }
        }else {
            //本地方法场景
            MyParams jcxx = LjqManager.jcxx(JsonUtil.clone(myParams),UserManager.findUser(scuser));
            //合并参数
            JsonUtil.mergeJSONObject(jcxx,myParams);
            //设置数据
            jcxx.sys().setEditTableData(list);
            result = LjqManager.data(jcxx);
            if(!result.isStatus()){
                throw new MyException("方法执行异常："+result);
            }
        }
        job.setBz(result.getMsg());
        if (result.getCode() == 200 || result.getCode() == 1000) {
            //正常成功或穿透调用超时算成功
            job.setJg(Yxzt.SUCCESS.getCode());
        }else {
            job.setJg(Yxzt.FAILED.getCode());
        }
        return list;
    }
}
