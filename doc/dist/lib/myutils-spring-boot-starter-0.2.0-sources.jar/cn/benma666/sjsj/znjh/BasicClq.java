package cn.benma666.sjsj.znjh;

import cn.benma666.iframe.BasicObject;
import cn.benma666.iframe.MyParams;
import cn.benma666.sjsj.job.BasicJob;
import com.alibaba.fastjson.JSONObject;

import java.util.List;

/**
 * 基础处理器
 */
public abstract class BasicClq extends BasicObject implements Runnable{
    /**
     * 批量处理
     * @param myParams 相关参数
     * @param list 数据
     * @param job 任务
     * @return 数据
     * @throws Exception 异常
     */
    public abstract List<JSONObject> plcl(MyParams myParams, List<JSONObject> list, BasicJob job) throws Exception;

    /**
     * 推送数据到下一步
     * @param list 数据列表
     */
    protected void putList(List<JSONObject> list){

    }

    /**
     * 结束推送
     */
    protected void putEnd(){

    }
}
