/**
 * Project Name:sjsj
 * Date:2021年8月30日
 * Copyright (c) 2021, jingma All Rights Reserved.
 */

package cn.benma666.sjsj.web;

import cn.benma666.exception.MyException;
import cn.benma666.iframe.BasicObject;
import cn.benma666.iframe.MyParams;
import cn.benma666.iframe.Result;
import cn.benma666.myutils.WebUtil;
import cn.benma666.sjsj.myutils.AMyParams;
import com.alibaba.fastjson.JSON;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.net.HttpURLConnection;
import java.util.Map;

/**
 * 系统web请求控制层，本系统只有这一个控制器<br/>
 * date: 2021年8月30日 <br/>
 * @author jingma
 */
@RestController
public class IndexController extends BasicObject implements ErrorController {
    private final ErrorAttributes errorAttributes;

    public IndexController(ErrorAttributes errorAttributes) {
        this.errorAttributes = errorAttributes;
    }

    /**
     * 系统入口
     */
    @RequestMapping(value = {"/default","/default/{dxdm}","/default/{dxdm}/{cllx}","/default/{dxdm}/{cllx}/{key}",
            "${benma666.service.addr}","${benma666.service.addr}/{dxdm}/{cllx}",
            "${benma666.service.addr}/{dxdm}","${benma666.service.addr}/{dxdm}/{cllx}/{key}",
            "/sjdx/{dxdm}/{cllx}","/auth/{authCode}/{cllx}",
            "/sjdx/{dxdm}","/auth/{authCode}",
            "/sjdx/{dxdm}/{cllx}/{key}","/auth/{authCode}/{cllx}/{key}"},
            method = {RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT})
    public Result index(@AMyParams MyParams myParams) {
        Result r;
        try {
            log.trace("进入控制器");
            r = LjqManager.data(myParams);
        }catch (MyException e){
            r = e.getResult();
            log.trace(r.toString(),e);
        }catch (Throwable e){
            r = failed("处理异常："+e.getMessage());
            r.setCode(HttpURLConnection.HTTP_INTERNAL_ERROR);
            log.error(r.getMsg(),e);
        }
        return r;
    }
    /**
     * 系统入口-文件上传
     */
    @RequestMapping(value = {"/default","/default/{dxdm}/{cllx}",
            "${benma666.service.addr}","${benma666.service.addr}/{dxdm}/{cllx}",
            "/sjdx/{dxdm}/{cllx}","/auth/{authCode}/{cllx}"},
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            method = {RequestMethod.GET,RequestMethod.POST})
    public Result upload(@AMyParams MyParams myParams,
                      @RequestParam("files") MultipartFile[] files) {
        Result r;
        try {
            r = LjqManager.upload(myParams, files);
        }catch (MyException e){
            r = e.getResult();
            log.trace(r.toString(),e);
        }catch (Throwable e){
            r = failed("处理异常："+e.getMessage());
            r.setCode(HttpURLConnection.HTTP_INTERNAL_ERROR);
            log.error(r.getMsg(),e);
        }
        return r;
    }
    /**
     * 系统范围外的异常
     * @param request 请求
     * @param ex 异常对象
     */
    @RequestMapping(value = "/execption", method = {RequestMethod.GET,RequestMethod.POST})
    @ExceptionHandler(value = {Throwable.class})
    public Result error(HttpServletRequest request, final Exception ex) {
        ServletWebRequest requestAttributes = new ServletWebRequest(request);
        Map<String, Object> attr = this.errorAttributes.getErrorAttributes(requestAttributes,
                ErrorAttributeOptions.defaults());
        try {
            log.warn("请求异常：" + WebUtil.getIpAddr(request) + ">" + JSON.toJSONString(request.getParameterMap())
                    + ">" + JSON.toJSONString(attr), ex);
        }catch (Throwable t){
            log.error("打印异常失败",t);
        }
        //        r.setCode(Integer.parseInt(attr.get("status").toString()));
        return failed("请求异常："+attr.get("error")+"->"+ex.getMessage());
    }
}
