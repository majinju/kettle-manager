/**
 * Project Name:myutils
 * Date:2018年12月16日
 * Copyright (c) 2018, jingma All Rights Reserved.
 */

package cn.benma666.sjsj.web;

import cn.benma666.dict.Cllx;
import cn.benma666.domain.SysQxYhxx;
import cn.benma666.domain.SysSjglFile;
import cn.benma666.domain.SysSjglSjdx;
import cn.benma666.exception.MyException;
import cn.benma666.iframe.*;
import cn.benma666.myutils.JsonUtil;
import cn.benma666.myutils.StringUtil;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashSet;
import java.util.Set;

import static cn.benma666.constants.UtilConstInstance.KEY_USER;
import static cn.benma666.constants.UtilConstInstance.KEY_YOBJ;

/**
 * 系统-数据管理-拦截器管理 <br/>
 * date: 2018年12月16日 <br/>
 * @author jingma
 */
@Component
public class LjqManager extends BasicObject {
    /**
     * spring容器，可以从中获取注册的bean
     */
    private static ApplicationContext context;
    /**
     * 拦截器结合，用于重复判断，避免再次出现注入单例对象
     */
    private static final Set<LjqInterface> ljqSet = new HashSet<>();
    /**
     * 虚拟对象
     */
    private static SysSjglSjdx xndx;
    /**
     * http请求响应对象
     */
    private static InheritableThreadLocal<HttpServletResponse> httpServletResponseITL = new InheritableThreadLocal<>();
    /**
     * http请求对象
     */
    private static InheritableThreadLocal<HttpServletRequest> HttpServletRequestITL = new InheritableThreadLocal<>();

    public LjqManager(ApplicationContext context){
        LjqManager.context = context;
        //给虚拟对象赋值
        xndx = new SysSjglSjdx();
        xndx.setId("912769435779405698B51852FB4277DB");
        //初始化虚拟对象的拦截器
        use(xndx);
    }
    /**
     * 使用对应的拦截器 <br/>
     * 对象中配置的拦截器>对象代码注解设置的拦截器>默认拦截器
     * @param sjdx 数据对象
     * @return 拦截器
     * @author jingma
     */
    public static LjqInterface use(SysSjglSjdx sjdx) {
        if(sjdx==null){
            //没有数据对象就采用虚拟对象获取拦截器
            sjdx = xndx;
        }
        LjqInterface ljq = (LjqInterface) sjdx.getLjqObj();
        if (ljq == null) {
            String ljqStr = sjdx.getLjq();
            if(isBlank(ljqStr)&&!isBlank(sjdx.getDxdm())){
                //没有在对象中配置拦截器
                try{
                    ljq = (LjqInterface) context.getBean(sjdx.getDxdm());
                }catch (NoSuchBeanDefinitionException t){
                    //通过对象代码没有找到bean,忽略
                }
            }
            //没有通过对象代码找到拦截器
            if(ljq==null){
                //没有配置拦截器
                if(isBlank(ljqStr)){
                    //从配置文件中读取默认拦截器
                    ljqStr = valByDef(Conf.getUtilConfig().getLjqDefault(),"MyDefaultLjq");
                }
                try{
                    // 支持从spring容器中取拦截器，从而支持开发在拦截器中使用spring的注解
                    ljq = (LjqInterface) context.getBean(ljqStr);
                }catch (NoSuchBeanDefinitionException t){
                    //没有找到，忽略
                    try{
                        Class<?> ljqClass = Class.forName(ljqStr);
                        try{
                            // 支持从spring容器中取拦截器，从而支持开发在拦截器中使用spring的注解
                            ljq = (LjqInterface) context.getBean(ljqClass);
                        }catch (Throwable t1){
                            // 实例化定制拦截器
                            ljq = (LjqInterface) ljqClass.getConstructor().newInstance();
                        }
                    } catch (Exception e) {
                        slog.error("拦截器实例化失败："+e.getMessage(), e);
                        throw new MyException("拦截器实例化失败："+e.getMessage(), e);
                    }
                }
            }
            //每个对象实例是独立的拦截器实例，同一个对象多次请求共用的同一个拦截器实例
            if(ljqSet.contains(ljq)){
                throw new MyException("拦截器必须是多例，该拦截配置不正确："+ljqStr);
            }
            ljqSet.add(ljq);
            sjdx.setLjqObj(ljq);
            ljq.setDlLjq(ljq);
            ljq.setSjdx(sjdx);
            ljq.init();
        }
        return ljq;
    }
    /**
     * 获取数据对象基础信息 <br/>
     * @param id 数据对象id
     * @return 基础信息
     * @author jingma
     */
    public static MyParams jcxxById(String id) {
        return jcxxById(id,null);
    }
    /**
     * 获取数据对象基础信息 <br/>
     * @param id 数据对象id
     * @return 基础信息
     * @author jingma
     */
    public static MyParams jcxxById(String id, SysQxYhxx user) {
        MyParams myParams = new MyParams();
        myParams.sjdx().setId(id);
        return jcxx(myParams,user);
    }
    /**
     * 获取数据对象基础信息 <br/>
     * @param dxdm 数据对象代码
     * @return 基础信息
     * @author jingma
     */
    public static MyParams jcxxByDxdm(String dxdm) {
        return jcxxByDxdm(dxdm,null);
    }
    public static MyParams jcxxByDxdm(String dxdm, SysQxYhxx user) {
        MyParams myParams = new MyParams(true);
        myParams.sjdx().setDxdm(dxdm);
        return jcxx(myParams,user);
    }
    /**
     * 获取数据对象基础信息 <br/>
     * @param authCode 数据对象代码
     * @return 基础信息
     * @author jingma
     */
    public static MyParams jcxxByAuthCode(String authCode) {
        return jcxxByAuthCode(authCode,null);
    }
    public static MyParams jcxxByAuthCode(String authCode, SysQxYhxx user) {
        MyParams myParams = new MyParams(true);
        myParams.sys().setAuthCode(authCode);
        return jcxx(myParams,user);
    }

    public static MyParams jcxx(MyParams myParams, SysQxYhxx user) {
        return jcxx(myParams,user,true);
    }
    /**
     * 自定义参数获取对象信息-内部调用
     * @param myParams 自定义参数
     * @param user 用户信息
     * @return 对象参数
     */
    public static MyParams jcxx(MyParams myParams, SysQxYhxx user,boolean nbdy) {
        if(!myParams.containsKey(LjqInterface.KEY_YOBJ)){
            myParams.put(LjqInterface.KEY_YOBJ,new JSONObject());
        }
        myParams.sys().setNbdy(nbdy);
        //设置请求id
        myParams.sys().setQqid(StringUtil.getUUIDUpperStr());
        if(isBlank(myParams.sys().getCllx())){
            myParams.sys().setCllx(Cllx.dxjcxx.name());
        }else {
            //此处一般是内部调用场景，自动设置基础参数备份
            myParams.other().setYsParams(JsonUtil.clone(myParams));
        }
        if(user!=null){
            myParams.put(KEY_USER,user);
        }
        return jcxx(myParams, nbdy);
    }

    /**
     * 获取基础信息
     *
     * @param myParams 相关参数
     */
    public static MyParams jcxx(MyParams myParams,boolean nbdy) {
        return use(xndx).initSjdx(myParams,nbdy);
    }

    /**
     * 获取数据对象基础信息 <br/>
     *
     * @param sjdx     数据对象
     * @param myParams 相关参数
     * @return 基础信息
     * @author jingma
     */
    public static MyParams jcxx(SysSjglSjdx sjdx, MyParams myParams) {
        return use(sjdx).jcxx(myParams);
    }

    /**
     * 数据处理 <br/>
     * @param myParams 相关参数
     * @return 基础信息
     * @author jingma
     */
    public static Result data(MyParams myParams) {
        return use(myParams.sjdx()).data(myParams);
    }

    /**
     * 文件上传 <br/>
     * @param myParams 相关参数
     * @param files 文件列表
     * @return 基础信息
     * @author jingma
     */
    public static Result upload(MyParams myParams,MultipartFile[] files) throws Exception {
        return use(myParams.sjdx()).upload(myParams,files);
    }
    /**
     * 验证规则 <br/>
     * @param myParams 相关参数
     * @author jingma
     */
    public static void yzgz(MyParams myParams) {
        use(myParams.sjdx()).yzgz(myParams);
    }
    /**
     * 分页查询 <br/>
     *
     * @param myParams 相关参数
     * @return 基础信息
     * @author jingma
     */
    public static Result select(MyParams myParams) {
        return use(myParams.sjdx()).select(myParams);
    }
    public static Result insert(MyParams myParams){
        return use(myParams.sjdx()).insert(myParams);
    }
    public static Result update(MyParams myParams) {
        return use(myParams.sjdx()).update(myParams);
    }
    public static Result save(MyParams myParams) {
        return use(myParams.sjdx()).save(myParams);
    }
    /**
     * 获取sql <br/>
     *
     * @param myParams 相关参数
     * @return 0:数据载体，1：sql
     * @author jingma
     */
    public static String[] getSql(MyParams myParams) {
        return use(myParams.sjdx()).getSql(myParams);
    }
    /**
     * 获取sql <br/>
     *
     * @param myParams 相关参数
     * @param cllx 相关参数
     * @return 0:数据载体，1：sql
     * @author jingma
     */
    public static String[] getSql(MyParams myParams,String cllx) {
        return use(myParams.sjdx()).getSql(myParams,cllx);
    }
    /**
     * 结果发送到前端
     * @param response 返回对象
     * @param myParams 相关参数
     * @param r 结果
     */
    public static void sendResult(HttpServletResponse response,MyParams myParams, Result r) {
        if(myParams==null){
            myParams = new MyParams();
        }
        try {
            use(myParams.sjdx()).sendResult(response,myParams,r);
        }catch (Throwable t){
            slog.error("结果处理失败",t);
            r.addMsg("结果处理失败："+t.getMessage());
            use(xndx).sendResult(response,myParams,r);
        }
    }

    /**
     * 流式查询
     * @param sql 要执行的sq，非默认数据载体则在sql后追加;ds=xxx
     * @param pageSize 分页大小
     * @param hdff 回调方法
     * @return 执行结果
     */
    public static Result streamSelect(String sql, int pageSize, HdInterface hdff){
        return streamSelect(sql,pageSize,hdff,6000000,null);
    }
    /**
     * 流式查询
     * @param sql 要执行的sq，非默认数据载体则在sql后追加;ds=xxx
     * @param pageSize 分页大小
     * @param hdff 回调方法
     * @param timeout 超时时长，默认6000000
     * @param ctapp 穿透的app
     * @return 执行结果
     */
    public static Result streamSelect(String sql,int pageSize,HdInterface hdff,int timeout,String ctapp){
        MyParams myParams = new MyParams();
        myParams.sjdx().setDxdm("SYS_COMMON_XNDX");
        myParams.sys().setCllx(Cllx.select.name());
        myParams.page().setTotalRequired(true);
        myParams.sys().setCtapp(ctapp);
        myParams.znjh().setSql(sql);
        myParams.page().setPageSize(pageSize);
        myParams.sys().setTimeout(timeout);
        //内部调用
        MyParams jcxx = LjqManager.jcxx(myParams, UserManager.findUser(valByDef(Conf.getUtilConfig().getZnjh().getUser(),"sys")));
        jcxx.sys().setHdcst(hdff);
        return LjqManager.data(jcxx);
    }
    /**
     * 远程sql执行
     * @param sjzt 要执行的数据载体
     * @param sql 要执行的sql
     * @param ctapp 要穿透的应用
     * @return 执行结果
     */
    public static Result ycSqlExecute(String sjzt,String sql,String ctapp){
        return ycSqlExecute(sjzt,sql,ctapp,600000);
    }
    /**
     * 远程sql执行
     * @param sjzt 要执行的数据载体
     * @param sql 要执行的sql
     * @param ctapp 要穿透的应用
     * @param timeout 超时时长，默认600000
     * @return 执行结果
     */
    public static Result ycSqlExecute(String sjzt,String sql,String ctapp,Integer timeout){
        return ycSqlExecute(sjzt,sql,ctapp,timeout,null);
    }
    /**
     * 远程sql执行
     * @param sjzt 要执行的数据载体
     * @param sql 要执行的sql
     * @param ctapp 要穿透的应用
     * @param timeout 超时时长，默认600000
     * @param zxfs 处理方式，可以是select、update，默认自动根据sql识别
     * @return 执行结果
     */
    public static Result ycSqlExecute(String sjzt,String sql,String ctapp,Integer timeout,String zxfs){
        JSONObject yobj = new JSONObject();
        yobj.put("sjzt",sjzt);
        yobj.put("zxsql",sql);
        yobj.put("zxfs",zxfs);
        //内部调用
        return fwdy(ctapp,"SYS_TYGJ_SQLZX",Cllx.insert.name(), yobj,timeout);
    }
    /**
     * 服务调用
     * @param ctapp 穿透APP
     * @param dxdm 对象代码
     * @param cllx 处理类型
     * @param yobj 原参数
     * @return 调用结果
     */
    public static Result fwdy(String ctapp,String dxdm,String cllx,JSONObject yobj){
        return fwdy(ctapp,dxdm,cllx,yobj,null);
    }

    /**
     * 服务调用
     * @param ctapp 穿透APP
     * @param dxdm 对象代码
     * @param cllx 处理类型
     * @param yobj 原参数
     * @param timeout 请求超时时间
     * @return 调用结果
     */
    public static Result fwdy(String ctapp,String dxdm,String cllx,JSONObject yobj,Integer timeout){
        MyParams myParams = new MyParams();
        myParams.sjdx().setDxdm(dxdm);
        myParams.sys().setCllx(cllx);
        myParams.sys().setCtapp(ctapp);
        myParams.put(KEY_YOBJ,yobj);
        myParams.sys().setTimeout(timeout);
        return fwdy(myParams);
    }

    /**
     * 服务调用
     */
    public static Result fwdy(MyParams myParams){
        //内部调用
        MyParams jcxx = LjqManager.jcxx(myParams, valByDef(myParams.getObject(KEY_USER,SysQxYhxx.class),
                UserManager.findUser(valByDef(Conf.getUtilConfig().getZnjh().getUser(),"sys"))));
        return LjqManager.data(jcxx);
    }

    /**
     * 内部上传文件
     * @param file 文件对象
     * @param user 用户信息
     * @return 结果
     */
    public static SysSjglFile upload(SysSjglFile file,SysQxYhxx user){
        MyParams jcxx = LjqManager.jcxxByAuthCode("QTQX",user);
        jcxx.put(KEY_YOBJ, file);
        jcxx.sys().setCllx(Cllx.upload.name());
        return LjqManager.data(jcxx).getData(SysSjglFile.class);
    }

    public static HttpServletResponse getHttpServletResponse() {
        return httpServletResponseITL.get();
    }

    public static void setHttpServletResponse(HttpServletResponse httpServletResponse) {
        httpServletResponseITL.set(httpServletResponse);
    }

    public static HttpServletRequest getHttpServletRequest() {
        return HttpServletRequestITL.get();
    }

    public static void setHttpServletRequest(HttpServletRequest httpServletRequest) {
        HttpServletRequestITL.set(httpServletRequest);
    }
}
