package cn.benma666.sjsj.myutils;

import cn.benma666.config.Benma666;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "benma666")
public class UtilConfig extends Benma666 {
}
