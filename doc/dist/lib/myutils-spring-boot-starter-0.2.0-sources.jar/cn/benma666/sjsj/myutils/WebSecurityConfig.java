package cn.benma666.sjsj.myutils;

import cn.benma666.iframe.Conf;
import cn.benma666.myutils.StringUtil;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.DefaultLoginPageConfigurer;

@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        super.configure(auth);
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/druid/**","/sjdx**","/auth**","/default**","/xtxx/**",
                "/"+Conf.getUtilConfig().getService().getAddr()+"**");
        if(StringUtil.isNotBlank(Conf.getUtilConfig().getService().getSecurityAddr())){
            web.ignoring().antMatchers(Conf.getUtilConfig().getService().getSecurityAddr().toArray(new String[0]));
        }
        super.configure(web);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
//        http.authorizeRequests().antMatchers("/actuator").hasRole("admin")
//                .and().authorizeRequests().mvcMatchers("**").permitAll();
        super.configure(http);
        //禁用spring security默认登录页
        http.removeConfigurer(DefaultLoginPageConfigurer.class);
    }

}
