package cn.benma666.sjsj.myutils;

import cn.benma666.iframe.BasicObject;
import cn.benma666.iframe.DefaultLog;
import cn.benma666.sjsj.job.ZnjhJob;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * 应用初始化-启动智能交换
 */
@Component
@ConditionalOnProperty("benma666.znjh.app-init-start")
public class ZnjhInit extends BasicObject implements ApplicationRunner {
    @Override
    public void run(ApplicationArguments args) {
        //智能交换-应用初始化启动
        new Thread(() -> ZnjhJob.start(new DefaultLog(),"2M")).start();
    }
}
