package cn.benma666.sjsj.myutils;

import cn.benma666.exception.MyException;
import cn.benma666.iframe.Conf;
import cn.benma666.myutils.Log;
import org.springframework.core.env.PropertySource;

/**
 * 我的配置源
 */
public class MyPropertySource extends PropertySource<Conf> {
    public MyPropertySource(String name, Conf source) {
        super(name, source);
    }

    public MyPropertySource(String name) {
        super(name);
    }

    @Override
    public Object getProperty(String name) {
        try {
            return Conf.getValByDict(name);
        }catch (MyException e){
            //忽略，数据库还未初始化
            Log.getLogger().trace("获取配置异常：{}",name,e);
            return null;
        }
    }
}
