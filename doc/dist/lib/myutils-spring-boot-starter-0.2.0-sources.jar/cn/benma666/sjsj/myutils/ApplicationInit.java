package cn.benma666.sjsj.myutils;

import cn.benma666.constants.UtilConst;
import cn.benma666.domain.SysSjglSjzt;
import cn.benma666.iframe.BasicObject;
import cn.benma666.iframe.Conf;
import cn.benma666.iframe.DictManager;
import cn.benma666.iframe.MyLogBackAppender;
import cn.benma666.sjzt.Db;
import com.alibaba.fastjson.JSON;
import org.beetl.sql.core.SqlId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 应用初始化
 */
@Component
@Order(9999)
public class ApplicationInit extends BasicObject implements ApplicationRunner {
    @Autowired
    private UtilConfig utilConfig;
    @Override
    public void run(ApplicationArguments args) {
        //给日志管理设置线程池，用于写日志入库的线程隔离
        MyLogBackAppender.setTp(ThreadPool.use());
        //系统初始化加载自动设置系统属性
        for (String key: DictManager.zdMap("SYS_COMMON_XTSX").keySet()){
            System.setProperty(key,DictManager.zdMcByDm("SYS_COMMON_XTSX",key));
        }
        //根据配置文件修改default数据载体信息，便于系统中自动识别默认数据载体相关信息
        db().update(SqlId.of("sjsj","updateSjzt"), Db.buildMap(Conf.getVal("spring.datasource.url"),
                Conf.getVal("spring.datasource.username"),db().getDbType().name(), UtilConst.DEFAULT));
        if(utilConfig.getDatasource()!=null){
            // 根据配置文件修改数据载体信息，便于系统中自动识别默认数据载体相关信息，
            // 从而支持所有数据载体采用配置文件进行配置，便于部署工作
            for(String dm: utilConfig.getDatasource().keySet()){
                SysSjglSjzt sjzt = utilConfig.getDatasource().get(dm);
                sjzt.setDm(dm);
                db().update(SqlId.of("sjsj","updateSjzt"), Db.buildMap(sjzt.getLjc(),
                        sjzt.getYhm(),sjzt.getLx(),dm));
            }
        }
        log.trace("系统属性：{}", JSON.toJSONString(System.getProperties()));
        log.info("启动成功,启动参数：{}", JSON.toJSONString(args));
    }
}
