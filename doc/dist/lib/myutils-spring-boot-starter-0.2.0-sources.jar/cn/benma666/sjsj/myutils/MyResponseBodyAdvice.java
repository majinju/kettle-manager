package cn.benma666.sjsj.myutils;

import cn.benma666.iframe.Result;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * 对返回值进行处理
 */
@ControllerAdvice(annotations = {RestController.class})
public class MyResponseBodyAdvice implements ResponseBodyAdvice {
    @Override
    public boolean supports(MethodParameter returnType, Class converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType,
                                  MediaType selectedContentType, Class selectedConverterType,
                                  ServerHttpRequest request, ServerHttpResponse response) {
        if(body instanceof Result){
            ((ServletServerHttpRequest)request).getServletRequest().setAttribute(MyHandlerInterceptor.RETURN_BODY,body);
            //自行进行结果处理，此处返回空，避免重复发送报错
            return null;
        }
        return body;
    }
}
